    /* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/


#ifndef OBD_H
#define OBD_H

#include <stdint.h> // For uint8_t, uint16_t, etc.
#include "stdbool.h"
    
    
// OBD-II PIDs
#define OBDII_PID_ENGINE_RPM 0x0C
#define OBDII_PID_VEHICLE_SPEED 0x0D
#define OBDII_PID_COOLANT_TEMP 0x05
#define OBDII_PID_THROTTLE_POS 0x11
#define OBDII_MODE_GET_DTC 0x03 
#define MAX_CAN_FRAME_LENGTH 8
#define MAX_MESSAGE_LENGTH 4096  // Adjust based on expected maximum message length
#define OBDII_MODE_CLEAR_DTC 0x04 // Mode 4 to clear DTCs
#define OBDII_MODE_GET_PENDING_DTC 0x07 // Mode 7 to get pending DTCs    
    
// External variables (declare them if they are used outside obd.c)
extern uint8_t RxMessage1[8];
extern uint8_t RXDLC1;
extern uint8_t RXFLAG1;
extern uint8_t TxMessage1[8];

// Function prototypes
void sendOBDRequest(uint8_t pid);
void sendMode3Request();
void PrintMessageOverUART(uint8_t *message, uint8_t length);
void ProcessAndDisplayOBDData(uint8_t *message, uint8_t length);
void processMode3Response();
void sendFreezeFrameRequest();
void displayOBDDataForPID(uint8_t pid);

void processStartOfMultiFrame(uint8_t *data, uint8_t length);
void continueMultiFrame(uint8_t *data, uint8_t length);
void processSingleFrame(uint8_t *data, uint8_t length);

bool isReceivingMultiFrame;
void processDTCResponse(uint8_t mode);
void handleDeleteCodes();
extern volatile int keepRunningCurrentAction;
uint8_t animation_count;

void sendMode9Request();
void sendMode06Request();
void animateLoading(const uint8_t frame[][288], char* str);

void processFreezeFrameData();
void displayPendingDTCs();
void displayStoredDTCs();

#endif // OBD_H


/* [] END OF FILE */
