#include "project.h"
#include "numbers.h"
#include "display.h"
#include "letters.h"
#include "frames.h"
#include "obd.h"
#include "menu.h"
#include <stdio.h>


// Forward Declarations

#define WIDTH 32
#define HEIGHT 32

#define NUMBER_OF_MENU_ITEMS 4

uint8_t output[128];


CY_ISR(UP_ISR) {
    navigateUp();
}

CY_ISR(DOWN_ISR) {
    navigateDown();
}

CY_ISR(RIGHT_ISR) {
    RIGHT_ClearPending();
    turnOffAllPixels();
    selectMenuItem();
}

CY_ISR(LEFT_ISR) {
    LEFT_ClearPending();
    turnOffAllPixels();
    keepRunningCurrentAction = 0; // This will break the loop in displayOBDDataForPID
    animation_count = 0;
    goBack();
    
}

int main(void) {
    CyGlobalIntEnable;  // Enable global interrupts
    
    CyDelay(300);
    
    
    UART_1_Start();
    EEPROM_1_Start();
    
    VDAC8_1_Start();
    Opamp_1_Start();
    VDAC8_1_SetValue(255);
    //Initialize CAN
    CAN_1_Init();
    UART_1_PutString("UART Test: If you see this, UART is working.\r\n");
    CAN_1_Start();
    initializeGraphicsMode();
    turnOnAllPixels();
    turnOffAllPixels();
    UP_ClearPending();         // Cancel any pending buz interrupts
    DOWN_ClearPending();
    RIGHT_ClearPending();
    LEFT_ClearPending();
    /*
    sendMode9Request();
    CyDelay(1000);
    UART_1_PutString("WE ARE OUT \n");
    CyDelay(1000);
    */
    UP_StartEx(UP_ISR);
    DOWN_StartEx(DOWN_ISR);
    RIGHT_StartEx(RIGHT_ISR);
    LEFT_StartEx(LEFT_ISR);
    turnOffAllPixels();
    /*
    displayText("OBD 2 READER",0,50);
    displayAnimation(intro,32,0,0,6);
    restartPixelRows(50,58,0,111);
    displayText("Done By",0,50);
    displayAnimation(intro,32,0,7,11);
    displayText("Ahmed Sami",0,50);
    displayAnimation(intro,32,0,11,17);
    UART_1_PutString("Hello\n");
    */
    turnOffAllPixels();
    initializeMainMenu();
    while(1) {
        CyDelay(200); 
    }
}
