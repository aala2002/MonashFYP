    /* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */
#include "numbers.h"
#include "display.h"
const uint8_t number0[64] = {
    224, 7, 56, 28, 12, 48, 6, 96, 6, 96, 6, 96, 6, 96, 6, 96, 6, 96, 6, 96, 6, 96, 6, 96, 6, 96, 6, 96, 12, 48, 56, 28, 224, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

const uint8_t number1[64] = {
    128, 1, 192, 1, 224, 1, 176, 1, 152, 1, 136, 1, 128, 1, 128, 1, 128, 1, 128, 1, 128, 1, 128, 1, 128, 1, 128, 1, 128, 1, 192, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

const uint8_t number2[64] = {
    240, 7, 24, 12, 8, 8, 0, 8, 0, 8, 0, 12, 0, 6, 0, 3, 128, 1, 192, 0, 96, 0, 48, 0, 24, 0, 12, 0, 254, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

const uint8_t number3[64] = {
    248, 7, 24, 12, 0, 8, 0, 8, 0, 12, 192, 7, 0, 12, 0, 24, 0, 24, 0, 24, 0, 24, 12, 12, 248, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

const uint8_t number4[64] = {
    0, 6, 0, 7, 128, 7, 192, 6, 96, 6, 48, 6, 24, 6, 12, 6, 6, 6, 3, 6, 255, 31, 0, 6, 0, 6, 0, 6, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

const uint8_t number5[64] = {
    248, 15, 248, 15, 8, 0, 8, 0, 8, 0, 248, 7, 248, 15, 0, 28, 0, 24, 0, 24, 0, 24, 0, 24, 12, 12, 248, 7, 240, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

const uint8_t number6[64] = {
    224, 7, 48, 12, 24, 24, 8, 0, 12, 0, 236, 3, 252, 7, 28, 12, 12, 24, 12, 24, 12, 24, 12, 24, 24, 12, 48, 6, 224, 3, 192, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

const uint8_t number7[64] = {
    254, 63, 254, 63, 0, 24, 0, 12, 0, 12, 0, 6, 0, 6, 0, 3, 0, 3, 128, 1, 128, 1, 192, 0, 192, 0, 96, 0, 96, 0, 48, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

const uint8_t number8[64] = {
    240, 3, 56, 14, 24, 12, 24, 12, 24, 12, 48, 6, 224, 3, 240, 7, 24, 12, 12, 24, 12, 24, 12, 24, 12, 24, 24, 12, 240, 7, 224, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

const uint8_t number9[64] = {
    240, 1, 248, 3, 12, 6, 6, 12, 6, 12, 6, 12, 6, 12, 12, 6, 248, 7, 240, 13, 0, 12, 0, 4, 0, 6, 24, 3, 240, 1, 224, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};



const uint8_t catBitmap[32] = {
    0x00, 0x00, // 00000000 00000000
    0x0C, 0x30, // 00001100 00110000
    0x12, 0x48, // 00010010 01001000
    0x12, 0x48, // 00010010 01001000
    0x0C, 0x30, // 00001100 00110000
    0x1E, 0x78, // 00011110 01111000
    0x33, 0xCC, // 00110011 11001100
    0x21, 0x84, // 00100001 10000100
    0x3F, 0xFC, // 00111111 11111100
    0x21, 0x84, // 00100001 10000100
    0x23, 0xC4, // 00100011 11000100
    0x1C, 0x38, // 00011100 00111000
    0x18, 0x18, // 00011000 00011000
    0x18, 0x18, // 00011000 00011000
    0x0F, 0xF0, // 00001111 11110000
    0x00, 0x00  // 00000000 00000000
};

const uint8_t* getNumberArray(int digit) {
    switch (digit) {
        case 0: return number0;
        case 1: return number1;
        case 2: return number2;
        case 3: return number3;
        case 4: return number4;
        case 5: return number5;
        case 6: return number6;
        case 7: return number7;
        case 8: return number8;
        case 9: return number9;
        default: return number0; // Invalid digit
    }
}

void displayNumber(int number, uint8_t startX, uint8_t startY) {
    if (number < 0 || number > 99999) {
        return; // Number is out of range
    }

    // Calculate hundreds, tens, and ones place values
    int tenthousands = number / 10000;
    int thousands = (number / 1000) % 10;
    int hundreds = (number / 100) % 10;
    int tens = (number / 10) % 10;
    int ones = number % 10;

    if (number < 10) {
        // Single digit (only ones place)
        displayImage(getNumberArray(0), startX, startY);
        displayImage(getNumberArray(0), startX + 16, startY);
        displayImage(getNumberArray(0), startX + 32, startY);
        displayImage(getNumberArray(ones), startX + 48, startY);
    } else if (number < 100) {
        // Double digits (tens and ones place)
        displayImage(getNumberArray(0), startX, startY);
        displayImage(getNumberArray(0), startX + 16, startY);
        displayImage(getNumberArray(tens), startX + 32, startY);
        displayImage(getNumberArray(ones), startX + 48, startY);
    } else if (number < 1000) {
        // Triple digits (hundreds, tens, and ones place)
        displayImage(getNumberArray(0), startX, startY);
        displayImage(getNumberArray(hundreds), startX + 16, startY);
        displayImage(getNumberArray(tens), startX + 32, startY);
        displayImage(getNumberArray(ones), startX + 48, startY);
    } else if (number < 10000) {
        // quadruple digits (thousands, hundreds, tens, and ones place)
        displayImage(getNumberArray(thousands), startX, startY);
        displayImage(getNumberArray(hundreds), startX + 16, startY);
        displayImage(getNumberArray(tens), startX + 32, startY);
        displayImage(getNumberArray(ones), startX + 48, startY);
    } else {
        // quintuple digits (tenthousand, thousands, hundreds, tens, and ones place)
        displayImage(getNumberArray(tenthousands), startX, startY);
        displayImage(getNumberArray(thousands), startX + 16, startY);
        displayImage(getNumberArray(hundreds), startX + 32, startY);
        displayImage(getNumberArray(tens), startX + 48, startY);
        displayImage(getNumberArray(ones), startX + 64, startY);
    }
}