/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#ifndef DISPLAY_H
#define DISPLAY_H

#include <stdint.h>

uint8_t currentData;    
void Custom_LCD_Data_Write(uint8_t data);
uint8_t Custom_LCD_Data_Read(void);
void sendCommand(uint8_t cmd);
void sendData(uint8_t data);
void setGDRAMAddress(uint8_t x, uint8_t y);
uint8_t readData(uint8_t skipDummy);
void initializeLCD(void);
void initializeGraphicsMode(void);
//void displayText(const char* str);
void turnOnAllPixels(void);
void restartPixelRows(uint8_t startY, uint8_t endY);
void turnOffAllPixels(void);
void setWord(uint8_t x, uint8_t y, uint8_t byte1, uint8_t byte2);
void setPixel(uint8_t x, uint8_t y);
void displayImage(const uint8_t* data, uint8_t startX, uint8_t startY);
void displayImage32(const uint8_t* data, uint8_t startX, uint8_t startY);
void displayImage64(const uint8_t* data, uint8_t startX, uint8_t startY);

void displayAnimation(const uint8_t frames[][288], uint8_t startX, uint8_t startY, int startFrame, int endFrame);
void setWord180(uint8_t x, uint8_t y, uint8_t byte1, uint8_t byte2);
void displayLine(uint8_t startY);
#endif // DISPLAY_H

