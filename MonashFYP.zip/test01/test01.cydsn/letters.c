/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#include "letters.h"
#include "project.h"
#include "display.h"

// Character 'A'
const uint8_t charA[8] = {
    0x00, // 00000000
    0x38, // 00111000
    0x44, // 01000100
    0x44, // 01000100
    0x7C, // 01111100
    0x44, // 01000100
    0x44, // 01000100
    0x00  // 00000000
};

// Character 'B'
const uint8_t charB[8] = {
    0x00, // 00000000
    0x3C, // 00111100
    0x44, // 01000100
    0x3C, // 00111100
    0x44, // 01000100
    0x44, // 01000100
    0x3C, // 00111100
    0x00  // 00000000
};

// Character 'C'
const uint8_t charC[8] = {
    0x00, // 00000000
    0x78, // 01111000
    0x44, // 01000100
    0x04, // 00000100
    0x04, // 00000100
    0x44, // 01000100
    0x78, // 01111000
    0x00  // 00000000
};

// Character 'D'
const uint8_t charD[8] = {
    0x00, // 00000000
    0x3C, // 00111100
    0x44, // 01000100
    0x44, // 01000100
    0x44, // 01000100
    0x44, // 01000100
    0x3C, // 00111100
    0x00  // 00000000
};

// Character 'E'
const uint8_t charE[8] = {
    0x00, // 00000000
    0x7C, // 01111100
    0x04, // 00000100
    0x3C, // 00111100
    0x04, // 00000100
    0x04, // 00000100
    0x7C, // 01111100
    0x00  // 00000000
};

// Character 'F'
const uint8_t charF[8] = {
    0x00, // 00000000
    0x7C, // 01111100
    0x04, // 00000100
    0x3C, // 00111100
    0x04, // 00000100
    0x04, // 00000100
    0x04, // 00000100
    0x00  // 00000000
};

// Character 'G'
const uint8_t charG[8] = {
    0x00, // 00000000
    0x78, // 01111000
    0x44, // 01000100
    0x04, // 00000100
    0x64, // 01100100
    0x44, // 01000100
    0x78, // 01111000
    0x00  // 00000000
};

// Character 'H'
const uint8_t charH[8] = {
    0x00, // 00000000
    0x44, // 01000100
    0x44, // 01000100
    0x7C, // 01111100
    0x44, // 01000100
    0x44, // 01000100
    0x44, // 01000100
    0x00  // 00000000
};

// Character 'I'
const uint8_t charI[8] = {
    0x00, // 00000000
    0x38, // 00111000
    0x10, // 00010000
    0x10, // 00010000
    0x10, // 00010000
    0x10, // 00010000
    0x38, // 00111000
    0x00  // 00000000
};

// Character 'J'
const uint8_t charJ[8] = {
    0x00, // 00000000
    0x70, // 01110000
    0x20, // 00100000
    0x20, // 00100000
    0x20, // 00100000
    0x24, // 00100100
    0x18, // 00011000
    0x00  // 00000000
};

// Character 'K'
const uint8_t charK[8] = {
    0x00, // 00000000
    0x44, // 01000100
    0x24, // 00100100
    0x14, // 00010100
    0x0C, // 00001100
    0x14, // 00010100
    0x24, // 00100100
    0x00  // 00000000
};

// Character 'L'
const uint8_t charL[8] = {
    0x00, // 00000000
    0x04, // 00000100
    0x04, // 00000100
    0x04, // 00000100
    0x04, // 00000100
    0x04, // 00000100
    0x7C, // 01111100
    0x00  // 00000000
};

// Character 'M'
const uint8_t charM[8] = {
    0x00, // 00000000
    0x44, // 01000100
    0x6C, // 01101100
    0x54, // 01010100
    0x44, // 01000100
    0x44, // 01000100
    0x44, // 01000100
    0x00  // 00000000
};

// Character 'N'
const uint8_t charN[8] = {
    0x00, // 00000000
    0x44, // 01000100
    0x4C, // 01001100
    0x54, // 01010100
    0x64, // 01100100
    0x44, // 01000100
    0x44, // 01000100
    0x00  // 00000000
};

// Character 'O'
const uint8_t charO[8] = {
    0x00, // 00000000
    0x38, // 00111000
    0x44, // 01000100
    0x44, // 01000100
    0x44, // 01000100
    0x44, // 01000100
    0x38, // 00111000
    0x00  // 00000000
};

// Character 'P'
const uint8_t charP[8] = {
    0x00, // 00000000
    0x3C, // 00111100
    0x44, // 01000100
    0x44, // 01000100
    0x3C, // 00111100
    0x04, // 00000100
    0x04, // 00000100
    0x00  // 00000000
};

// Character 'Q'
const uint8_t charQ[8] = {
    0x00, // 00000000
    0x38, // 00111000
    0x44, // 01000100
    0x44, // 01000100
    0x64, // 01100100
    0x58, // 01011000
    0x38, // 00111000
    0x00  // 00000000
};

// Character 'R'
const uint8_t charR[8] = {
    0x00, // 00000000
    0x3C, // 00111100
    0x44, // 01000100
    0x44, // 01000100
    0x3C, // 00111100
    0x24, // 00100100
    0x44, // 01000100
    0x00  // 00000000
};

// Character 'S'
const uint8_t charS[8] = {
    0x00, // 00000000
    0x78, // 01111000
    0x04, // 00000100
    0x04, // 00000100
    0x38, // 00111000
    0x40, // 01000000
    0x3C, // 00111100
    0x00  // 00000000
};

// Character 'T'
const uint8_t charT[8] = {
    0x00, // 00000000
    0x7C, // 01111100
    0x10, // 00010000
    0x10, // 00010000
    0x10, // 00010000
    0x10, // 00010000
    0x10, // 00010000
    0x00  // 00000000
};

// Character 'U'
const uint8_t charU[8] = {
    0x00, // 00000000
    0x44, // 01000100
    0x44, // 01000100
    0x44, // 01000100
    0x44, // 01000100
    0x44, // 01000100
    0x38, // 00111000
    0x00  // 00000000
};

// Character 'V'
const uint8_t charV[8] = {
    0x00, // 00000000
    0x44, // 01000100
    0x44, // 01000100
    0x44, // 01000100
    0x44, // 01000100
    0x28, // 00101000
    0x10, // 00010000
    0x00  // 00000000
};

// Character 'W'
const uint8_t charW[8] = {
    0x00, // 00000000
    0x44, // 01000100
    0x44, // 01000100
    0x54, // 01010100
    0x54, // 01010100
    0x54, // 01010100
    0x28, // 00101000
    0x00  // 00000000
};

// Character 'X'
const uint8_t charX[8] = {
    0x00, // 00000000
    0x44, // 01000100
    0x28, // 00101000
    0x10, // 00010000
    0x28, // 00101000
    0x44, // 01000100
    0x44, // 01000100
    0x00  // 00000000
};

// Character 'Y'
const uint8_t charY[8] = {
    0x00, // 00000000
    0x44, // 01000100
    0x28, // 00101000
    0x10, // 00010000
    0x10, // 00010000
    0x10, // 00010000
    0x10, // 00010000
    0x00  // 00000000
};

// Character 'Z'
const uint8_t charZ[8] = {
    0x00, // 00000000
    0x7C, // 01111100
    0x40, // 01000000
    0x20, // 00100000
    0x10, // 00010000
    0x08, // 00001000
    0x7C, // 01111100
    0x00  // 00000000
};

// Character 'Space'
const uint8_t charSpace[8] = {
    0x00, // 00000000
    0x00, // 00000000
    0x00, // 00000000
    0x00, // 00000000
    0x00, // 00000000
    0x00, // 00000000
    0x00, // 00000000
    0x00  // 00000000
};

// Character 'a'
const uint8_t charA_small[8] = {
    0x00, // 00000000
    0x00, // 00000000
    0x38, // 00111000
    0x40, // 01000000
    0x78, // 01111000
    0x44, // 01000100
    0x78, // 01111000
    0x00  // 00000000
};

// Character 'b'
const uint8_t charB_small[8] = {
    0x04,0x04,0x34,0x4C,0x44,0x4C,0x34,0x00
};

// Character 'c'
const uint8_t charC_small[8] = {
    0x00,0x00,0x78,0x04,0x04,0x04,0x78,0x00
};

// Character 'd'
const uint8_t charD_small[8] = {
    0x40,0x40,0x58,0x64,0x44,0x64,0x58,0x00
};

// Character 'e'
const uint8_t charE_small[8] = {
    0x00,0x00,0x38,0x44,0x7C,0x04,0x78,0x00
};

// Character 'f'
const uint8_t charF_small[8] = {
    0x70,0x08,0x08,0x7C,0x08,0x08,0x08,0x00
};

// Character 'g'
const uint8_t charG_small[8] = {
    0x00,0x00,0x58,0x64,0x44,0x64,0x58,0x40,0x38
};

// Character 'h'
const uint8_t charH_small[8] = {
    0x04,0x04,0x34,0x4C,0x44,0x44,0x44,0x00
};

// Character 'i'
const uint8_t charI_small[8] = {
    0x10,0x00,0x18,0x10,0x10,0x10,0x38,0x00
};

// Character 'j'
const uint8_t charJ_small[8] = {
    0x20,0x00,0x30,0x20,0x20,0x24,0x18,0x00
};

// Character 'k'
const uint8_t charK_small[8] = {
    0x04,0x04,0x24,0x14,0x0C,0x14,0x24,0x00
};

// Character 'l'
const uint8_t charL_small[8] = {
    0x18,0x10,0x10,0x10,0x10,0x10,0x38,0x00
};

// Character 'm'
const uint8_t charM_small[8] = {
    0x00,0x00,0x54,0x6C,0x44,0x44,0x44,0x00
};

// Character 'n'
const uint8_t charN_small[8] = {
    0x00,0x00,0x34,0x4C,0x44,0x44,0x44,0x00
};

// Character 'o'
const uint8_t charO_small[8] = {
    0x00,0x00,0x38,0x44,0x44,0x44,0x38,0x00
};

// Character 'p'
const uint8_t charP_small[8] = {
    0x00,0x00,0x3C,0x44,0x44,0x3C,0x04,0x04
};

// Character 'q'
const uint8_t charQ_small[8] = {
    0x00,0x00,0x58,0x64,0x44,0x78,0x40,0x40
};

// Character 'r'
const uint8_t charR_small[8] = {
    0x00,0x00,0x74,0x0C,0x04,0x04,0x04,0x00
};

// Character 's'
const uint8_t charS_small[8] = {
    0x00,0x00,0x78,0x04,0x38,0x40,0x3C,0x00
};

// Character 't'
const uint8_t charT_small[8] = {
    0x08,0x08,0x7C,0x08,0x08,0x08,0x70,0x00
};

// Character 'u'
const uint8_t charU_small[8] = {
    0x00,0x00,0x44,0x44,0x44,0x64,0x58,0x00
};

// Character 'v'
const uint8_t charV_small[8] = {
    0x00,0x00,0x44,0x44,0x44,0x28,0x10,0x00
};

// Character 'w'
const uint8_t charW_small[8] = {
    0x00,0x00,0x44,0x44,0x54,0x54,0x28,0x00
};

// Character 'x'
const uint8_t charX_small[8] = {
    0x00,0x00,0x44,0x28,0x10,0x28,0x44,0x00
};

// Character 'y'
const uint8_t charY_small[8] = {
    0x00,0x00,0x44,0x28,0x10,0x10,0x10,0x00
};

// Character 'z'
const uint8_t charZ_small[8] = {
    0x00,0x00,0x7C,0x20,0x10,0x08,0x7C,0x00
};

// Number '0' adjusted for 180-degree rotation
const uint8_t char0[8] = {
    0x38, // 00111000
    0x44, // 01000100
    0x64, // 01100100
    0x54, // 01010100
    0x4C, // 01001100
    0x44, // 01000100
    0x38, // 00111000
    0x00, // 00000000
};

// Number '1' adjusted for 180-degree rotation
const uint8_t char1[8] = {
    0x10, // 00010000
    0x18, // 00011000
    0x14, // 00010100
    0x10, // 00010000
    0x10, // 00010000
    0x10, // 00010000
    0x7C, // 01111100
    0x00, // 00000000
};

// Number '2' adjusted for 180-degree rotation
const uint8_t char2[8] = {
    0x38, // 00111000
    0x44, // 01000100
    0x40, // 01000000
    0x30, // 00110000
    0x08, // 00001000
    0x04, // 00000100
    0x7C, // 01111100
    0x00, // 00000000
};

// Number '3' adjusted for 180-degree rotation
const uint8_t char3[8] = {
    0x38, // 00111000
    0x44, // 01000100
    0x40, // 01000000
    0x30, // 00110000
    0x40, // 01000000
    0x44, // 01000100
    0x38, // 00111000
    0x00, // 00000000
};

// Number '4' adjusted for 180-degree rotation
const uint8_t char4[8] = {
    0x20, // 00100000
    0x30, // 00110000
    0x28, // 00101000
    0x24, // 00100100
    0x7C, // 01111100
    0x20, // 00100000
    0x20, // 00100000
    0x00, // 00000000
};

// Number '5' adjusted for 180-degree rotation
const uint8_t char5[8] = {
    0x7C, // 01111100
    0x04, // 00000100
    0x3C, // 00111100
    0x40, // 01000000
    0x40, // 01000000
    0x44, // 01000100
    0x38, // 00111000
    0x00, // 00000000
};

// Number '6' adjusted for 180-degree rotation
const uint8_t char6[8] = {
    0x38, // 00111000
    0x44, // 01000100
    0x04, // 00000100
    0x3C, // 00111100
    0x44, // 01000100
    0x44, // 01000100
    0x38, // 00111000
    0x00, // 00000000
};

// Number '7' adjusted for 180-degree rotation
const uint8_t char7[8] = {
    0x7C, // 01111100
    0x40, // 01000000
    0x20, // 00100000
    0x10, // 00010000
    0x08, // 00001000
    0x08, // 00001000
    0x08, // 00001000
    0x00, // 00000000
};

// Number '8' adjusted for 180-degree rotation
const uint8_t char8bit[8] = {
    0x38, // 00111000
    0x44, // 01000100
    0x44, // 01000100
    0x38, // 00111000
    0x44, // 01000100
    0x44, // 01000100
    0x38, // 00111000
    0x00, // 00000000
};

// Number '9' adjusted for 180-degree rotation
const uint8_t char9[8] = {
    0x38, // 00111000
    0x44, // 01000100
    0x44, // 01000100
    0x78, // 01111000
    0x40, // 01000000
    0x44, // 01000100
    0x38, // 00111000
    0x00, // 00000000
};

// Character 'Bullet Point'
const uint8_t charBullet[8] = {
    0x00, // 00000000
    0x00, // 00000000
    0x00, // 00000000
    0x18, // 00011000
    0x18, // 00011000
    0x00, // 00000000
    0x00, // 00000000
    0x00  // 00000000
};

// Character 'Right Arrow'
const uint8_t charArrowRight[8] = {
    0x00, // 00000000
    0x10, // 00010000
    0x30, // 00110000
    0x7F, // 01111111
    0x7F, // 01111111
    0x30, // 00110000
    0x10, // 00010000
    0x00  // 00000000
};

const uint8_t* getCharBitmap(char c) {
    switch (c) {
        case 'A': return charA;
        case 'B': return charB;
        case 'C': return charC;
        case 'D': return charD;
        case 'E': return charE;
        case 'F': return charF;
        case 'G': return charG;
        case 'H': return charH;
        case 'I': return charI;
        case 'J': return charJ;
        case 'K': return charK;
        case 'L': return charL;
        case 'M': return charM;
        case 'N': return charN;
        case 'O': return charO;
        case 'P': return charP;
        case 'Q': return charQ;
        case 'R': return charR;
        case 'S': return charS;
        case 'T': return charT;
        case 'U': return charU;
        case 'V': return charV;
        case 'W': return charW;
        case 'X': return charX;
        case 'Y': return charY;
        case 'Z': return charZ;
        case 'a': return charA_small;
        case 'b': return charB_small;
        case 'c': return charC_small;
        case 'd': return charD_small;
        case 'e': return charE_small;
        case 'f': return charF_small;
        case 'g': return charG_small;
        case 'h': return charH_small;
        case 'i': return charI_small;
        case 'j': return charJ_small;
        case 'k': return charK_small;
        case 'l': return charL_small;
        case 'm': return charM_small;
        case 'n': return charN_small;
        case 'o': return charO_small;
        case 'p': return charP_small;
        case 'q': return charQ_small;
        case 'r': return charR_small;
        case 's': return charS_small;
        case 't': return charT_small;
        case 'u': return charU_small;
        case 'v': return charV_small;
        case 'w': return charW_small;
        case 'x': return charX_small;
        case 'y': return charY_small;
        case 'z': return charZ_small;
        case ' ': return charSpace;
        case '0': return char0;
        case '1': return char1;
        case '2': return char2;
        case '3': return char3;
        case '4': return char4;
        case '5': return char5;
        case '6': return char6;
        case '7': return char7;
        case '8': return char8bit;
        case '9': return char9;
        case '*': return charBullet;
        case '>': return charArrowRight;
        
        default: return NULL; // Invalid digit
    }
}
