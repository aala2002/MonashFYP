/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * ======PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// obd.c
#include "obd.h"
#include "project.h" // Include if required for CAN_1_SendMsg0(), UART_1_PutString(), etc.
#include <stdio.h>   // For sprintf()
#include <string.h>  // For strcat()
#include "numbers.h"
#include "display.h"
#include "menu.h"
#include "stdbool.h"
#include "CAN_1.h"
#include "frames.h"
#include "EEPROM_1.h"


// Define the variables here
uint8_t RxMessage1[8];
uint8_t RXDLC1;
uint8_t RXFLAG1;
uint8_t TxMessage1[8] = {0x02, 0x01, 0x00, 0, 0, 0, 0, 0};

volatile int keepRunningCurrentAction = 0;
#define STORED_DTC_EEPROM_ADDRESS 0x00
#define PENDING_DTC_EEPROM_ADDRESS 0x100



/*
uint8_t messageBuffer[MAX_MESSAGE_LENGTH];
uint16_t messageBufferIndex = 0;
bool isReceivingMultiFrame = false;
*/

/*
void saveDTCsToEEPROM(uint8_t *data, uint8_t length, uint16_t startAddress) {
    EEPROM_1_UpdateTemperature(); // Ensure EEPROM is ready for writing

    // Write the DTC count
    UART_1_PutString("Writing to EEPROM:\r\n");
    char uartBuffer[50];
    sprintf(uartBuffer, "Address: 0x%04X, Data: 0x%02X\r\n", startAddress, data[2]);
    UART_1_PutString(uartBuffer);
    startAddress++;

    // Write the DTCs
    for (int i = 0; i < length; i++) {
        EEPROM_1_WriteByte(data[i], startAddress);
        sprintf(uartBuffer, "Address: 0x%04X, Data: 0x%02X\r\n", startAddress, data[i]);
        UART_1_PutString(uartBuffer);
        startAddress++;
    }
}

void readDTCsFromEEPROM(uint16_t startAddress, uint8_t *buffer, uint8_t maxLength) {
    uint8_t dtcCount = EEPROM_1_ReadByte(startAddress);
    startAddress++;

    // Ensure we don't read more than the maximum buffer length
    uint8_t bytesToRead = (dtcCount * 2 < maxLength) ? dtcCount * 2 : maxLength;

    for (int i = 0; i < bytesToRead; i++) {
        buffer[i] = EEPROM_1_ReadByte(startAddress++);
    }
}
*/

void animateLoading(const uint8_t frame[][288], char* str) {
    if (animation_count == 0) {
        displayText("LOADING...",48,50);
        displayAnimation(frame,48,0,0,10);
        turnOffAllPixels();
        displayText(str,0,0);
        displayLine(8);
    }
    
    animation_count = 1;
};
void sendOBDRequest(uint8_t pid) {
    TxMessage1[2] = pid;
    CAN_1_SendMsg0(); 
}

void sendMode3Request() {
    // Mode 3 request format: {number of additional data bytes, service ID}
    uint8_t mode3TxMessage[8] = {0x01, OBDII_MODE_GET_DTC, 0, 0, 0, 0, 0, 0};
    memcpy(TxMessage1, mode3TxMessage, 8);
    CAN_1_SendMsg0(); 
}
void sendMode4Request() {
    
    // Mode 4 request format: {number of additional data bytes, service ID}
    uint8_t mode4TxMessage[8] = {0x01, OBDII_MODE_CLEAR_DTC, 0, 0, 0, 0, 0, 0};
    memcpy(TxMessage1, mode4TxMessage, 8);
    CAN_1_SendMsg0();
}
void sendMode7Request() {
    
    // Mode 7 request format: {number of additional data bytes, service ID}
    uint8_t mode7TxMessage[8] = {0x01, OBDII_MODE_GET_PENDING_DTC, 0, 0, 0, 0, 0, 0};
    memcpy(TxMessage1, mode7TxMessage, 8);
    CAN_1_SendMsg0();
}

void sendFreezeFrameRequest() {
    uint8_t freezeFrameTxMessage[8] = {0x01, 0x02, 0, 0, 0, 0, 0, 0}; // Mode 02, PID 0x0C for engine RPM freeze frame.
    UART_1_PutString("test \n");
    memcpy(TxMessage1, freezeFrameTxMessage, 8);
    CAN_1_SendMsg0();
}


void sendMode06Request() {
    
    uint8_t mode06TxMessage[8] = {0x01, 0x06, 0x00, 0, 0, 0, 0, 0}; // Mode 06, request all test results
    memcpy(TxMessage1, mode06TxMessage, 8);
    CAN_1_SendMsg0();
}

void sendMode9Request() {
    
    // Mode 9 request format: {number of additional data bytes, service ID, PID}
    uint8_t mode9TxMessage[8] = {0x02, 0x09, 0x02, 0, 0, 0, 0, 0}; // Mode 09, PID for VIN is typically 0x02
    memcpy(TxMessage1, mode9TxMessage, 8);
    CAN_1_SendMsg0();
}

void displayOBDDataForPID(uint8_t pid) {
    turnOffAllPixels();
    while(keepRunningCurrentAction) {
        RXFLAG1 = 0; // Assume this resets the flag
        sendOBDRequest(pid);
        
        
        // Wait for the response
        while(RXFLAG1 != 1 && keepRunningCurrentAction) {
        }
        
        // Assuming RxMessage1 and the length is appropriate for all PIDs
        if (currentDataType == INTERPRETED_DATA) {
            ProcessAndDisplayOBDData(RxMessage1, 8);
        } else {
            
        }
    }
}
void displayDTCs(uint8_t *data, uint8_t length) {
    uint8_t responseType = data[1];
    char uartBuffer[50];
    sprintf(uartBuffer, "Response Type: 0x%02X\r\n", responseType);
    UART_1_PutString(uartBuffer);

    sprintf(uartBuffer, "Length: %d\r\n", length);
    UART_1_PutString(uartBuffer);
    int dtcCount = data[2];
    uint8_t startY = 10;
    animateLoading(error,"DTC CODES");

    if (dtcCount == 0) {
        displayText("NO DTC", 0, 0);
    } else {
        // Save DTCs to EEPROM
        if (responseType == 0x43) {
            //saveDTCsToEEPROM(data, length, STORED_DTC_EEPROM_ADDRESS);
            UART_1_PutString("HLLLO \n");
        } else if (responseType == 0x47) {
            //saveDTCsToEEPROM(data, length, PENDING_DTC_EEPROM_ADDRESS);
        }
        UART_1_PutString("NOOO \n");
        // Iterate through the received message to extract DTCs
        for (int i = 3, count = 1; i < 3 + dtcCount * 2; i += 2, count++) {
            if (i + 1 < length) {  // Ensure not to read beyond received data
                char dtcString[10];  // Increase size to accommodate the count and asterisk
                uint8_t firstByte = data[i];
                uint8_t secondByte = data[i + 1];

                char type = 'P';  // Default to 'P' for Powertrain
                switch(firstByte >> 6) {
                    case 0: type = 'P'; break;  // Powertrain
                    case 1: type = 'C'; break;  // Chassis
                    case 2: type = 'B'; break;  // Body
                    case 3: type = 'U'; break;  // Network
                }
                sprintf(dtcString, "%d*%c%01X%02X", count, type, firstByte & 0x3F, secondByte);
                displayText(dtcString, 0, startY);
                startY += 8;  // Adjust for your display's character height
            }
        }
    }
}



void processDTCResponse(uint8_t mode) {
    turnOffAllPixels();
    RXFLAG1 = 0;  // Clear the flag immediately to avoid processing old data

    // Send request based on mode
    if (mode == OBDII_MODE_GET_DTC) {
        sendMode3Request();  // Send confirmed DTC request
    } else if (mode == OBDII_MODE_GET_PENDING_DTC) {
        sendMode7Request();  // Send pending DTC request
    }

    while(keepRunningCurrentAction) {
        // Wait for the response
        turnOffAllPixels();
        CyDelay(100);
        while(RXFLAG1 != 1 && keepRunningCurrentAction);
        
        // Check the response format and process DTCs
        if (RXDLC1 > 2 && (RxMessage1[1] == 0x43 || RxMessage1[1] == 0x47)) {
            displayDTCs(RxMessage1, RXDLC1);
        } else {
            displayText("INVALID", 0, 0);
        }
        CyDelay(9000);
    }
}

void handleDeleteCodes() {
    turnOffAllPixels();
    sendMode4Request();
    displayText("DTCs CLEARED", 0, 0);
    CyDelay(2000);
}

void ProcessAndDisplayOBDData(uint8_t *message, uint8_t length) {
    if (length < 3) return; // Ensure there's enough data for PID and at least one data byte
    uint16_t A, B;
    uint32_t value; // Generic variable for calculated values
    char uartBuffer[100]; // Buffer for UART output
    
    switch(message[2]) { // Switch on the PID
        case OBDII_PID_ENGINE_RPM:
            animateLoading(gear," Engine RPM");
            if (length >= 5) { // Ensure enough data for RPM calculation          
                A = message[3];
                B = message[4];
                value = (256 * A + B) / 4;
                int frameIndex = (value - 800) / 20 + 13; // Calculate index offset from base RPM 800, starting at frame 13
                if (frameIndex < 13) {
                    frameIndex = 13; // Ensure frame index is not below minimum
                } else if (frameIndex > 27) {
                    frameIndex = 27; // Ensure frame index does not exceed maximum
                }
                displayImage32(speed_2[frameIndex], 48, 10); // Adjust array access since frameIndex starts at 13
                displayNumber(value, 32, 48);
                sprintf(uartBuffer, "Engine RPM: %u", value);
                UART_1_PutString(uartBuffer);
            }
            break;
        case OBDII_PID_VEHICLE_SPEED:
            if (length >= 4) { // Speed requires one data byte
                animateLoading(gear,"Vehichle Speed");
                A = message[3];
                value = A; // Speed is directly the value of A for this PID
                int frameIndex = (value - 800) / 20 + 13; // Calculate index offset from base RPM 800, starting at frame 13
                if (frameIndex < 13) {
                    frameIndex = 13; // Ensure frame index is not below minimum
                } else if (frameIndex > 27) {
                    frameIndex = 27; // Ensure frame index does not exceed maximum
                }
                displayImage32(speed_2[frameIndex - 13], 48, 10); // Adjust array access since frameIndex starts at 13
                displayNumber(value, 32, 48);
                turnOffAllPixels();
                //sprintf(uartBuffer, "Vehicle Speed: %lu km/h", value);
            }
            break;
        case OBDII_PID_COOLANT_TEMP:
            if (length >= 4) {
                A = message[3];
                value = A - 40; // Formula to convert A to temperature
                displayNumber(value, 32, 48);
                //sprintf(uartBuffer, "Coolant Temp: %lu°C", value);
            }
            break;
        case OBDII_PID_THROTTLE_POS:
            if (length >= 4) {
                A = message[3];
                value = (100 * A) / 255; // Formula to calculate throttle position
                displayNumber(value, 32, 48);
                //sprintf(uartBuffer, "Throttle Position: %lu%%", value);
            }
            break;
        // Add additional cases here for other PIDs
        default:
            //sprintf(uartBuffer, "Unknown or Unhandled PID: 0x%02X", message[2]);
            break;
    }

    // Add a check to ensure uartBuffer was modified from its initial state
    if (uartBuffer[0] != '\0') {
        UART_1_PutString(uartBuffer);
        UART_1_PutString("\r\n");
    }
}   

void processFreezeFrameResponse(uint8_t *data, uint8_t length) {
    // Assuming the first byte after the PID contains the DTC and the following bytes contain the data
    if (length < 3) return; // Not enough data received
    
    RXFLAG1 = 0;

    uint8_t DTC = data[1]; // DTC that triggered the freeze frame
    uint8_t dataValue = data[2]; // Actual data value for the PID requested

    char buffer[64];
    sprintf(buffer, "DTC: %02X, Data: %d", DTC, dataValue);
    displayText(buffer, 0, 0); // Display the freeze frame data
}

void processFreezeFrameData() {
    turnOffAllPixels();
    UART_1_PutString("HELLO \n");
    sendFreezeFrameRequest();  // Sending request with specific PID

    while(keepRunningCurrentAction) {
        // Wait for the response
        CyDelay(100);
        while(RXFLAG1 != 1 && keepRunningCurrentAction);

        turnOffAllPixels();
        // Check the response format and process data
        if (RXDLC1 > 3) {  // Assuming a minimum valid data length
            processFreezeFrameResponse(RxMessage1, RXDLC1);
        } else {
            displayText("INVALID DATA", 0, 0);
        }
        CyDelay(5000);  // Display result for 5 seconds or handle as needed
    }
}

void processMode06Response(uint8_t *data, uint8_t length) {
    if (length < 6) return; // Basic check for enough data

    uint8_t TID = data[2];
    uint8_t CID = data[3];
    uint16_t testValue = (data[4] << 8) | data[5]; // Assuming a 2-byte test value

    // Optional: Check for min/max values if included
    uint16_t minValue = (data[6] << 8) | data[7];
    uint16_t maxValue = (data[8] << 8) | data[9];

    char buffer[128];
    sprintf(buffer, "TID: %02X, CID: %02X, Value: %u, Min: %u, Max: %u", TID, CID, testValue, minValue, maxValue);
    displayText(buffer, 0, 0); // Display the Mode 06 data
}

void processMode06Data() {
    turnOffAllPixels();
    sendMode06Request();  // Send request for Mode 06 data

    while(keepRunningCurrentAction) {
        // Wait for the response
        CyDelay(100);
        while(RXFLAG1 != 1 && keepRunningCurrentAction);

        turnOffAllPixels();
        // Process the received Mode 06 data
        if (RXDLC1 > 5) {  // Assuming a minimum valid data length for Mode 06
            processMode06Response(RxMessage1, RXDLC1);
        } else {
            displayText("INVALID DATA", 0, 0);
        }
        CyDelay(5000);  // Display result for 5 seconds or handle as needed
    }
}
/*
void printEEPROMContents(uint16_t startAddress, uint8_t length) {
    char uartBuffer[100];
    for (uint8_t i = 0; i < length; i++) {
        uint8_t data = EEPROM_1_ReadByte(startAddress + i);
        sprintf(uartBuffer, "EEPROM Address: 0x%04X, Data: 0x%02X\r\n", startAddress + i, data);
        UART_1_PutString(uartBuffer);
    }
}
*/
/*
void debugEEPROM() {
    UART_1_PutString("Checking Stored DTCs in EEPROM:\r\n");
    printEEPROMContents(STORED_DTC_EEPROM_ADDRESS, 64);

    UART_1_PutString("Checking Pending DTCs in EEPROM:\r\n");
    printEEPROMContents(PENDING_DTC_EEPROM_ADDRESS, 64);
}
*/
/*
void displayStoredDTCs() {
    printEEPROMContents(STORED_DTC_EEPROM_ADDRESS,64);
    uint8_t dtcData[64] = {0}; // Adjust size as needed
    readDTCsFromEEPROM(STORED_DTC_EEPROM_ADDRESS, dtcData, sizeof(dtcData));
    keepRunningCurrentAction = 1;
    while (keepRunningCurrentAction) {
        displayDTCs(dtcData, sizeof(dtcData));
    }
}

void displayPendingDTCs() {
    uint8_t dtcData[64] = {0}; // Adjust size as needed
    readDTCsFromEEPROM(PENDING_DTC_EEPROM_ADDRESS, dtcData, sizeof(dtcData));
    displayDTCs(dtcData, sizeof(dtcData));
}
*/

 
