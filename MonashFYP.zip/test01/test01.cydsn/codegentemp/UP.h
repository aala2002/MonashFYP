/*******************************************************************************
* File Name: UP.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_UP_H)
#define CY_ISR_UP_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void UP_Start(void);
void UP_StartEx(cyisraddress address);
void UP_Stop(void);

CY_ISR_PROTO(UP_Interrupt);

void UP_SetVector(cyisraddress address);
cyisraddress UP_GetVector(void);

void UP_SetPriority(uint8 priority);
uint8 UP_GetPriority(void);

void UP_Enable(void);
uint8 UP_GetState(void);
void UP_Disable(void);

void UP_SetPending(void);
void UP_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the UP ISR. */
#define UP_INTC_VECTOR            ((reg32 *) UP__INTC_VECT)

/* Address of the UP ISR priority. */
#define UP_INTC_PRIOR             ((reg8 *) UP__INTC_PRIOR_REG)

/* Priority of the UP interrupt. */
#define UP_INTC_PRIOR_NUMBER      UP__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable UP interrupt. */
#define UP_INTC_SET_EN            ((reg32 *) UP__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the UP interrupt. */
#define UP_INTC_CLR_EN            ((reg32 *) UP__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the UP interrupt state to pending. */
#define UP_INTC_SET_PD            ((reg32 *) UP__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the UP interrupt. */
#define UP_INTC_CLR_PD            ((reg32 *) UP__INTC_CLR_PD_REG)


#endif /* CY_ISR_UP_H */


/* [] END OF FILE */
