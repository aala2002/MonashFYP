/*******************************************************************************
* File Name: PSB.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PSB_H) /* Pins PSB_H */
#define CY_PINS_PSB_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PSB_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 PSB__PORT == 15 && ((PSB__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    PSB_Write(uint8 value);
void    PSB_SetDriveMode(uint8 mode);
uint8   PSB_ReadDataReg(void);
uint8   PSB_Read(void);
void    PSB_SetInterruptMode(uint16 position, uint16 mode);
uint8   PSB_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the PSB_SetDriveMode() function.
     *  @{
     */
        #define PSB_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define PSB_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define PSB_DM_RES_UP          PIN_DM_RES_UP
        #define PSB_DM_RES_DWN         PIN_DM_RES_DWN
        #define PSB_DM_OD_LO           PIN_DM_OD_LO
        #define PSB_DM_OD_HI           PIN_DM_OD_HI
        #define PSB_DM_STRONG          PIN_DM_STRONG
        #define PSB_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define PSB_MASK               PSB__MASK
#define PSB_SHIFT              PSB__SHIFT
#define PSB_WIDTH              1u

/* Interrupt constants */
#if defined(PSB__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in PSB_SetInterruptMode() function.
     *  @{
     */
        #define PSB_INTR_NONE      (uint16)(0x0000u)
        #define PSB_INTR_RISING    (uint16)(0x0001u)
        #define PSB_INTR_FALLING   (uint16)(0x0002u)
        #define PSB_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define PSB_INTR_MASK      (0x01u) 
#endif /* (PSB__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PSB_PS                     (* (reg8 *) PSB__PS)
/* Data Register */
#define PSB_DR                     (* (reg8 *) PSB__DR)
/* Port Number */
#define PSB_PRT_NUM                (* (reg8 *) PSB__PRT) 
/* Connect to Analog Globals */                                                  
#define PSB_AG                     (* (reg8 *) PSB__AG)                       
/* Analog MUX bux enable */
#define PSB_AMUX                   (* (reg8 *) PSB__AMUX) 
/* Bidirectional Enable */                                                        
#define PSB_BIE                    (* (reg8 *) PSB__BIE)
/* Bit-mask for Aliased Register Access */
#define PSB_BIT_MASK               (* (reg8 *) PSB__BIT_MASK)
/* Bypass Enable */
#define PSB_BYP                    (* (reg8 *) PSB__BYP)
/* Port wide control signals */                                                   
#define PSB_CTL                    (* (reg8 *) PSB__CTL)
/* Drive Modes */
#define PSB_DM0                    (* (reg8 *) PSB__DM0) 
#define PSB_DM1                    (* (reg8 *) PSB__DM1)
#define PSB_DM2                    (* (reg8 *) PSB__DM2) 
/* Input Buffer Disable Override */
#define PSB_INP_DIS                (* (reg8 *) PSB__INP_DIS)
/* LCD Common or Segment Drive */
#define PSB_LCD_COM_SEG            (* (reg8 *) PSB__LCD_COM_SEG)
/* Enable Segment LCD */
#define PSB_LCD_EN                 (* (reg8 *) PSB__LCD_EN)
/* Slew Rate Control */
#define PSB_SLW                    (* (reg8 *) PSB__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PSB_PRTDSI__CAPS_SEL       (* (reg8 *) PSB__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PSB_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PSB__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PSB_PRTDSI__OE_SEL0        (* (reg8 *) PSB__PRTDSI__OE_SEL0) 
#define PSB_PRTDSI__OE_SEL1        (* (reg8 *) PSB__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PSB_PRTDSI__OUT_SEL0       (* (reg8 *) PSB__PRTDSI__OUT_SEL0) 
#define PSB_PRTDSI__OUT_SEL1       (* (reg8 *) PSB__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PSB_PRTDSI__SYNC_OUT       (* (reg8 *) PSB__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(PSB__SIO_CFG)
    #define PSB_SIO_HYST_EN        (* (reg8 *) PSB__SIO_HYST_EN)
    #define PSB_SIO_REG_HIFREQ     (* (reg8 *) PSB__SIO_REG_HIFREQ)
    #define PSB_SIO_CFG            (* (reg8 *) PSB__SIO_CFG)
    #define PSB_SIO_DIFF           (* (reg8 *) PSB__SIO_DIFF)
#endif /* (PSB__SIO_CFG) */

/* Interrupt Registers */
#if defined(PSB__INTSTAT)
    #define PSB_INTSTAT            (* (reg8 *) PSB__INTSTAT)
    #define PSB_SNAP               (* (reg8 *) PSB__SNAP)
    
	#define PSB_0_INTTYPE_REG 		(* (reg8 *) PSB__0__INTTYPE)
#endif /* (PSB__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_PSB_H */


/* [] END OF FILE */
