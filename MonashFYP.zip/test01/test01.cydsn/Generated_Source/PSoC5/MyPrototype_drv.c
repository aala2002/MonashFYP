/***************************************************************************//**
* \file MyPrototype_drv.c
* \version 3.20
*
* \brief
*  This file contains the Endpoint 0 Driver for the USBFS Component.  
*
********************************************************************************
* \copyright
* Copyright 2008-2016, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "MyPrototype_pvt.h"
#include "cyapicallbacks.h"


/***************************************
* Global data allocation
***************************************/

volatile T_MyPrototype_EP_CTL_BLOCK MyPrototype_EP[MyPrototype_MAX_EP];

/** Contains the current configuration number, which is set by the host using a 
 * SET_CONFIGURATION request. This variable is initialized to zero in 
 * USBFS_InitComponent() API and can be read by the USBFS_GetConfiguration() 
 * API.*/
volatile uint8 MyPrototype_configuration;

/** Contains the current interface number.*/
volatile uint8 MyPrototype_interfaceNumber;

/** This variable is set to one after SET_CONFIGURATION and SET_INTERFACE 
 *requests. It can be read by the USBFS_IsConfigurationChanged() API */
volatile uint8 MyPrototype_configurationChanged;

/** Contains the current device address.*/
volatile uint8 MyPrototype_deviceAddress;

/** This is a two-bit variable that contains power status in the bit 0 
 * (DEVICE_STATUS_BUS_POWERED or DEVICE_STATUS_SELF_POWERED) and remote wakeup 
 * status (DEVICE_STATUS_REMOTE_WAKEUP) in the bit 1. This variable is 
 * initialized to zero in USBFS_InitComponent() API, configured by the 
 * USBFS_SetPowerStatus() API. The remote wakeup status cannot be set using the 
 * API SetPowerStatus(). */
volatile uint8 MyPrototype_deviceStatus;

volatile uint8 MyPrototype_interfaceSetting[MyPrototype_MAX_INTERFACES_NUMBER];
volatile uint8 MyPrototype_interfaceSetting_last[MyPrototype_MAX_INTERFACES_NUMBER];
volatile uint8 MyPrototype_interfaceStatus[MyPrototype_MAX_INTERFACES_NUMBER];

/** Contains the started device number. This variable is set by the 
 * USBFS_Start() or USBFS_InitComponent() APIs.*/
volatile uint8 MyPrototype_device;

/** Initialized class array for each interface. It is used for handling Class 
 * specific requests depend on interface class. Different classes in multiple 
 * alternate settings are not supported.*/
const uint8 CYCODE *MyPrototype_interfaceClass;


/***************************************
* Local data allocation
***************************************/

volatile uint8  MyPrototype_ep0Toggle;
volatile uint8  MyPrototype_lastPacketSize;

/** This variable is used by the communication functions to handle the current 
* transfer state.
* Initialized to TRANS_STATE_IDLE in the USBFS_InitComponent() API and after a 
* complete transfer in the status stage.
* Changed to the TRANS_STATE_CONTROL_READ or TRANS_STATE_CONTROL_WRITE in setup 
* transaction depending on the request type.
*/
volatile uint8  MyPrototype_transferState;
volatile T_MyPrototype_TD MyPrototype_currentTD;
volatile uint8  MyPrototype_ep0Mode;
volatile uint8  MyPrototype_ep0Count;
volatile uint16 MyPrototype_transferByteCount;


/*******************************************************************************
* Function Name: MyPrototype_ep_0_Interrupt
****************************************************************************//**
*
*  This Interrupt Service Routine handles Endpoint 0 (Control Pipe) traffic.
*  It dispatches setup requests and handles the data and status stages.
*
*
*******************************************************************************/
CY_ISR(MyPrototype_EP_0_ISR)
{
    uint8 tempReg;
    uint8 modifyReg;

#ifdef MyPrototype_EP_0_ISR_ENTRY_CALLBACK
    MyPrototype_EP_0_ISR_EntryCallback();
#endif /* (MyPrototype_EP_0_ISR_ENTRY_CALLBACK) */
    
    tempReg = MyPrototype_EP0_CR_REG;
    if ((tempReg & MyPrototype_MODE_ACKD) != 0u)
    {
        modifyReg = 1u;
        if ((tempReg & MyPrototype_MODE_SETUP_RCVD) != 0u)
        {
            if ((tempReg & MyPrototype_MODE_MASK) != MyPrototype_MODE_NAK_IN_OUT)
            {
                /* Mode not equal to NAK_IN_OUT: invalid setup */
                modifyReg = 0u;
            }
            else
            {
                MyPrototype_HandleSetup();
                
                if ((MyPrototype_ep0Mode & MyPrototype_MODE_SETUP_RCVD) != 0u)
                {
                    /* SETUP bit set: exit without mode modificaiton */
                    modifyReg = 0u;
                }
            }
        }
        else if ((tempReg & MyPrototype_MODE_IN_RCVD) != 0u)
        {
            MyPrototype_HandleIN();
        }
        else if ((tempReg & MyPrototype_MODE_OUT_RCVD) != 0u)
        {
            MyPrototype_HandleOUT();
        }
        else
        {
            modifyReg = 0u;
        }
        
        /* Modify the EP0_CR register */
        if (modifyReg != 0u)
        {
            
            tempReg = MyPrototype_EP0_CR_REG;
            
            /* Make sure that SETUP bit is cleared before modification */
            if ((tempReg & MyPrototype_MODE_SETUP_RCVD) == 0u)
            {
                /* Update count register */
                tempReg = (uint8) MyPrototype_ep0Toggle | MyPrototype_ep0Count;
                MyPrototype_EP0_CNT_REG = tempReg;
               
                /* Make sure that previous write operaiton was successful */
                if (tempReg == MyPrototype_EP0_CNT_REG)
                {
                    /* Repeat until next successful write operation */
                    do
                    {
                        /* Init temporary variable */
                        modifyReg = MyPrototype_ep0Mode;
                        
                        /* Unlock register */
                        tempReg = (uint8) (MyPrototype_EP0_CR_REG & MyPrototype_MODE_SETUP_RCVD);
                        
                        /* Check if SETUP bit is not set */
                        if (0u == tempReg)
                        {
                            /* Set the Mode Register  */
                            MyPrototype_EP0_CR_REG = MyPrototype_ep0Mode;
                            
                            /* Writing check */
                            modifyReg = MyPrototype_EP0_CR_REG & MyPrototype_MODE_MASK;
                        }
                    }
                    while (modifyReg != MyPrototype_ep0Mode);
                }
            }
        }
    }

    MyPrototype_ClearSieInterruptSource(MyPrototype_INTR_SIE_EP0_INTR);
	
#ifdef MyPrototype_EP_0_ISR_EXIT_CALLBACK
    MyPrototype_EP_0_ISR_ExitCallback();
#endif /* (MyPrototype_EP_0_ISR_EXIT_CALLBACK) */
}


/*******************************************************************************
* Function Name: MyPrototype_HandleSetup
****************************************************************************//**
*
*  This Routine dispatches requests for the four USB request types
*
*
* \reentrant
*  No.
*
*******************************************************************************/
void MyPrototype_HandleSetup(void) 
{
    uint8 requestHandled;
    
    /* Clear register lock by SIE (read register) and clear setup bit 
    * (write any value in register).
    */
    requestHandled = (uint8) MyPrototype_EP0_CR_REG;
    MyPrototype_EP0_CR_REG = (uint8) requestHandled;
    requestHandled = (uint8) MyPrototype_EP0_CR_REG;

    if ((requestHandled & MyPrototype_MODE_SETUP_RCVD) != 0u)
    {
        /* SETUP bit is set: exit without mode modification. */
        MyPrototype_ep0Mode = requestHandled;
    }
    else
    {
        /* In case the previous transfer did not complete, close it out */
        MyPrototype_UpdateStatusBlock(MyPrototype_XFER_PREMATURE);

        /* Check request type. */
        switch (MyPrototype_bmRequestTypeReg & MyPrototype_RQST_TYPE_MASK)
        {
            case MyPrototype_RQST_TYPE_STD:
                requestHandled = MyPrototype_HandleStandardRqst();
                break;
                
            case MyPrototype_RQST_TYPE_CLS:
                requestHandled = MyPrototype_DispatchClassRqst();
                break;
                
            case MyPrototype_RQST_TYPE_VND:
                requestHandled = MyPrototype_HandleVendorRqst();
                break;
                
            default:
                requestHandled = MyPrototype_FALSE;
                break;
        }
        
        /* If request is not recognized. Stall endpoint 0 IN and OUT. */
        if (requestHandled == MyPrototype_FALSE)
        {
            MyPrototype_ep0Mode = MyPrototype_MODE_STALL_IN_OUT;
        }
    }
}


/*******************************************************************************
* Function Name: MyPrototype_HandleIN
****************************************************************************//**
*
*  This routine handles EP0 IN transfers.
*
*
* \reentrant
*  No.
*
*******************************************************************************/
void MyPrototype_HandleIN(void) 
{
    switch (MyPrototype_transferState)
    {
        case MyPrototype_TRANS_STATE_IDLE:
            break;
        
        case MyPrototype_TRANS_STATE_CONTROL_READ:
            MyPrototype_ControlReadDataStage();
            break;
            
        case MyPrototype_TRANS_STATE_CONTROL_WRITE:
            MyPrototype_ControlWriteStatusStage();
            break;
            
        case MyPrototype_TRANS_STATE_NO_DATA_CONTROL:
            MyPrototype_NoDataControlStatusStage();
            break;
            
        default:    /* there are no more states */
            break;
    }
}


/*******************************************************************************
* Function Name: MyPrototype_HandleOUT
****************************************************************************//**
*
*  This routine handles EP0 OUT transfers.
*
*
* \reentrant
*  No.
*
*******************************************************************************/
void MyPrototype_HandleOUT(void) 
{
    switch (MyPrototype_transferState)
    {
        case MyPrototype_TRANS_STATE_IDLE:
            break;
        
        case MyPrototype_TRANS_STATE_CONTROL_READ:
            MyPrototype_ControlReadStatusStage();
            break;
            
        case MyPrototype_TRANS_STATE_CONTROL_WRITE:
            MyPrototype_ControlWriteDataStage();
            break;
            
        case MyPrototype_TRANS_STATE_NO_DATA_CONTROL:
            /* Update the completion block */
            MyPrototype_UpdateStatusBlock(MyPrototype_XFER_ERROR);
            
            /* We expect no more data, so stall INs and OUTs */
            MyPrototype_ep0Mode = MyPrototype_MODE_STALL_IN_OUT;
            break;
            
        default:    
            /* There are no more states */
            break;
    }
}


/*******************************************************************************
* Function Name: MyPrototype_LoadEP0
****************************************************************************//**
*
*  This routine loads the EP0 data registers for OUT transfers. It uses the
*  currentTD (previously initialized by the _InitControlWrite function and
*  updated for each OUT transfer, and the bLastPacketSize) to determine how
*  many uint8s to transfer on the current OUT.
*
*  If the number of uint8s remaining is zero and the last transfer was full,
*  we need to send a zero length packet.  Otherwise we send the minimum
*  of the control endpoint size (8) or remaining number of uint8s for the
*  transaction.
*
*
* \globalvars
*  MyPrototype_transferByteCount - Update the transfer byte count from the
*     last transaction.
*  MyPrototype_ep0Count - counts the data loaded to the SIE memory in
*     current packet.
*  MyPrototype_lastPacketSize - remembers the USBFS_ep0Count value for the
*     next packet.
*  MyPrototype_transferByteCount - sum of the previous bytes transferred
*     on previous packets(sum of USBFS_lastPacketSize)
*  MyPrototype_ep0Toggle - inverted
*  MyPrototype_ep0Mode  - prepare for mode register content.
*  MyPrototype_transferState - set to TRANS_STATE_CONTROL_READ
*
* \reentrant
*  No.
*
*******************************************************************************/
void MyPrototype_LoadEP0(void) 
{
    uint8 ep0Count = 0u;

    /* Update the transfer byte count from the last transaction */
    MyPrototype_transferByteCount += MyPrototype_lastPacketSize;

    /* Now load the next transaction */
    while ((MyPrototype_currentTD.count > 0u) && (ep0Count < 8u))
    {
        MyPrototype_EP0_DR_BASE.epData[ep0Count] = (uint8) *MyPrototype_currentTD.pData;
        MyPrototype_currentTD.pData = &MyPrototype_currentTD.pData[1u];
        ep0Count++;
        MyPrototype_currentTD.count--;
    }

    /* Support zero-length packet */
    if ((MyPrototype_lastPacketSize == 8u) || (ep0Count > 0u))
    {
        /* Update the data toggle */
        MyPrototype_ep0Toggle ^= MyPrototype_EP0_CNT_DATA_TOGGLE;
        /* Set the Mode Register  */
        MyPrototype_ep0Mode = MyPrototype_MODE_ACK_IN_STATUS_OUT;
        /* Update the state (or stay the same) */
        MyPrototype_transferState = MyPrototype_TRANS_STATE_CONTROL_READ;
    }
    else
    {
        /* Expect Status Stage Out */
        MyPrototype_ep0Mode = MyPrototype_MODE_STATUS_OUT_ONLY;
        /* Update the state (or stay the same) */
        MyPrototype_transferState = MyPrototype_TRANS_STATE_CONTROL_READ;
    }

    /* Save the packet size for next time */
    MyPrototype_ep0Count =       (uint8) ep0Count;
    MyPrototype_lastPacketSize = (uint8) ep0Count;
}


/*******************************************************************************
* Function Name: MyPrototype_InitControlRead
****************************************************************************//**
*
*  Initialize a control read transaction. It is used to send data to the host.
*  The following global variables should be initialized before this function
*  called. To send zero length packet use InitZeroLengthControlTransfer
*  function.
*
*
* \return
*  requestHandled state.
*
* \globalvars
*  MyPrototype_currentTD.count - counts of data to be sent.
*  MyPrototype_currentTD.pData - data pointer.
*
* \reentrant
*  No.
*
*******************************************************************************/
uint8 MyPrototype_InitControlRead(void) 
{
    uint16 xferCount;

    if (MyPrototype_currentTD.count == 0u)
    {
        (void) MyPrototype_InitZeroLengthControlTransfer();
    }
    else
    {
        /* Set up the state machine */
        MyPrototype_transferState = MyPrototype_TRANS_STATE_CONTROL_READ;
        
        /* Set the toggle, it gets updated in LoadEP */
        MyPrototype_ep0Toggle = 0u;
        
        /* Initialize the Status Block */
        MyPrototype_InitializeStatusBlock();
        
        xferCount = ((uint16)((uint16) MyPrototype_lengthHiReg << 8u) | ((uint16) MyPrototype_lengthLoReg));

        if (MyPrototype_currentTD.count > xferCount)
        {
            MyPrototype_currentTD.count = xferCount;
        }
        
        MyPrototype_LoadEP0();
    }

    return (MyPrototype_TRUE);
}


/*******************************************************************************
* Function Name: MyPrototype_InitZeroLengthControlTransfer
****************************************************************************//**
*
*  Initialize a zero length data IN transfer.
*
* \return
*  requestHandled state.
*
* \globalvars
*  MyPrototype_ep0Toggle - set to EP0_CNT_DATA_TOGGLE
*  MyPrototype_ep0Mode  - prepare for mode register content.
*  MyPrototype_transferState - set to TRANS_STATE_CONTROL_READ
*  MyPrototype_ep0Count - cleared, means the zero-length packet.
*  MyPrototype_lastPacketSize - cleared.
*
* \reentrant
*  No.
*
*******************************************************************************/
uint8 MyPrototype_InitZeroLengthControlTransfer(void)
                                                
{
    /* Update the state */
    MyPrototype_transferState = MyPrototype_TRANS_STATE_CONTROL_READ;
    
    /* Set the data toggle */
    MyPrototype_ep0Toggle = MyPrototype_EP0_CNT_DATA_TOGGLE;
    
    /* Set the Mode Register  */
    MyPrototype_ep0Mode = MyPrototype_MODE_ACK_IN_STATUS_OUT;
    
    /* Save the packet size for next time */
    MyPrototype_lastPacketSize = 0u;
    
    MyPrototype_ep0Count = 0u;

    return (MyPrototype_TRUE);
}


/*******************************************************************************
* Function Name: MyPrototype_ControlReadDataStage
****************************************************************************//**
*
*  Handle the Data Stage of a control read transfer.
*
*
* \reentrant
*  No.
*
*******************************************************************************/
void MyPrototype_ControlReadDataStage(void) 

{
    MyPrototype_LoadEP0();
}


/*******************************************************************************
* Function Name: MyPrototype_ControlReadStatusStage
****************************************************************************//**
*
*  Handle the Status Stage of a control read transfer.
*
*
* \globalvars
*  MyPrototype_USBFS_transferByteCount - updated with last packet size.
*  MyPrototype_transferState - set to TRANS_STATE_IDLE.
*  MyPrototype_ep0Mode  - set to MODE_STALL_IN_OUT.
*
* \reentrant
*  No.
*
*******************************************************************************/
void MyPrototype_ControlReadStatusStage(void) 
{
    /* Update the transfer byte count */
    MyPrototype_transferByteCount += MyPrototype_lastPacketSize;
    
    /* Go Idle */
    MyPrototype_transferState = MyPrototype_TRANS_STATE_IDLE;
    
    /* Update the completion block */
    MyPrototype_UpdateStatusBlock(MyPrototype_XFER_STATUS_ACK);
    
    /* We expect no more data, so stall INs and OUTs */
    MyPrototype_ep0Mode = MyPrototype_MODE_STALL_IN_OUT;
}


/*******************************************************************************
* Function Name: MyPrototype_InitControlWrite
****************************************************************************//**
*
*  Initialize a control write transaction
*
* \return
*  requestHandled state.
*
* \globalvars
*  MyPrototype_USBFS_transferState - set to TRANS_STATE_CONTROL_WRITE
*  MyPrototype_ep0Toggle - set to EP0_CNT_DATA_TOGGLE
*  MyPrototype_ep0Mode  - set to MODE_ACK_OUT_STATUS_IN
*
* \reentrant
*  No.
*
*******************************************************************************/
uint8 MyPrototype_InitControlWrite(void) 
{
    uint16 xferCount;

    /* Set up the state machine */
    MyPrototype_transferState = MyPrototype_TRANS_STATE_CONTROL_WRITE;
    
    /* This might not be necessary */
    MyPrototype_ep0Toggle = MyPrototype_EP0_CNT_DATA_TOGGLE;
    
    /* Initialize the Status Block */
    MyPrototype_InitializeStatusBlock();

    xferCount = ((uint16)((uint16) MyPrototype_lengthHiReg << 8u) | ((uint16) MyPrototype_lengthLoReg));

    if (MyPrototype_currentTD.count > xferCount)
    {
        MyPrototype_currentTD.count = xferCount;
    }

    /* Expect Data or Status Stage */
    MyPrototype_ep0Mode = MyPrototype_MODE_ACK_OUT_STATUS_IN;

    return(MyPrototype_TRUE);
}


/*******************************************************************************
* Function Name: MyPrototype_ControlWriteDataStage
****************************************************************************//**
*
*  Handle the Data Stage of a control write transfer
*       1. Get the data (We assume the destination was validated previously)
*       2. Update the count and data toggle
*       3. Update the mode register for the next transaction
*
*
* \globalvars
*  MyPrototype_transferByteCount - Update the transfer byte count from the
*    last transaction.
*  MyPrototype_ep0Count - counts the data loaded from the SIE memory
*    in current packet.
*  MyPrototype_transferByteCount - sum of the previous bytes transferred
*    on previous packets(sum of USBFS_lastPacketSize)
*  MyPrototype_ep0Toggle - inverted
*  MyPrototype_ep0Mode  - set to MODE_ACK_OUT_STATUS_IN.
*
* \reentrant
*  No.
*
*******************************************************************************/
void MyPrototype_ControlWriteDataStage(void) 
{
    uint8 ep0Count;
    uint8 regIndex = 0u;

    ep0Count = (MyPrototype_EP0_CNT_REG & MyPrototype_EPX_CNT0_MASK) - MyPrototype_EPX_CNTX_CRC_COUNT;

    MyPrototype_transferByteCount += (uint8)ep0Count;

    while ((MyPrototype_currentTD.count > 0u) && (ep0Count > 0u))
    {
        *MyPrototype_currentTD.pData = (uint8) MyPrototype_EP0_DR_BASE.epData[regIndex];
        MyPrototype_currentTD.pData = &MyPrototype_currentTD.pData[1u];
        regIndex++;
        ep0Count--;
        MyPrototype_currentTD.count--;
    }
    
    MyPrototype_ep0Count = (uint8)ep0Count;
    
    /* Update the data toggle */
    MyPrototype_ep0Toggle ^= MyPrototype_EP0_CNT_DATA_TOGGLE;
    
    /* Expect Data or Status Stage */
    MyPrototype_ep0Mode = MyPrototype_MODE_ACK_OUT_STATUS_IN;
}


/*******************************************************************************
* Function Name: MyPrototype_ControlWriteStatusStage
****************************************************************************//**
*
*  Handle the Status Stage of a control write transfer
*
* \globalvars
*  MyPrototype_transferState - set to TRANS_STATE_IDLE.
*  MyPrototype_USBFS_ep0Mode  - set to MODE_STALL_IN_OUT.
*
* \reentrant
*  No.
*
*******************************************************************************/
void MyPrototype_ControlWriteStatusStage(void) 
{
    /* Go Idle */
    MyPrototype_transferState = MyPrototype_TRANS_STATE_IDLE;
    
    /* Update the completion block */    
    MyPrototype_UpdateStatusBlock(MyPrototype_XFER_STATUS_ACK);
    
    /* We expect no more data, so stall INs and OUTs */
    MyPrototype_ep0Mode = MyPrototype_MODE_STALL_IN_OUT;
}


/*******************************************************************************
* Function Name: MyPrototype_InitNoDataControlTransfer
****************************************************************************//**
*
*  Initialize a no data control transfer
*
* \return
*  requestHandled state.
*
* \globalvars
*  MyPrototype_transferState - set to TRANS_STATE_NO_DATA_CONTROL.
*  MyPrototype_ep0Mode  - set to MODE_STATUS_IN_ONLY.
*  MyPrototype_ep0Count - cleared.
*  MyPrototype_ep0Toggle - set to EP0_CNT_DATA_TOGGLE
*
* \reentrant
*  No.
*
*******************************************************************************/
uint8 MyPrototype_InitNoDataControlTransfer(void) 
{
    MyPrototype_transferState = MyPrototype_TRANS_STATE_NO_DATA_CONTROL;
    MyPrototype_ep0Mode       = MyPrototype_MODE_STATUS_IN_ONLY;
    MyPrototype_ep0Toggle     = MyPrototype_EP0_CNT_DATA_TOGGLE;
    MyPrototype_ep0Count      = 0u;

    return (MyPrototype_TRUE);
}


/*******************************************************************************
* Function Name: MyPrototype_NoDataControlStatusStage
****************************************************************************//**
*  Handle the Status Stage of a no data control transfer.
*
*  SET_ADDRESS is special, since we need to receive the status stage with
*  the old address.
*
* \globalvars
*  MyPrototype_transferState - set to TRANS_STATE_IDLE.
*  MyPrototype_ep0Mode  - set to MODE_STALL_IN_OUT.
*  MyPrototype_ep0Toggle - set to EP0_CNT_DATA_TOGGLE
*  MyPrototype_deviceAddress - used to set new address and cleared
*
* \reentrant
*  No.
*
*******************************************************************************/
void MyPrototype_NoDataControlStatusStage(void) 
{
    if (0u != MyPrototype_deviceAddress)
    {
        /* Update device address if we got new address. */
        MyPrototype_CR0_REG = (uint8) MyPrototype_deviceAddress | MyPrototype_CR0_ENABLE;
        MyPrototype_deviceAddress = 0u;
    }

    MyPrototype_transferState = MyPrototype_TRANS_STATE_IDLE;
    
    /* Update the completion block. */
    MyPrototype_UpdateStatusBlock(MyPrototype_XFER_STATUS_ACK);
    
    /* Stall IN and OUT, no more data is expected. */
    MyPrototype_ep0Mode = MyPrototype_MODE_STALL_IN_OUT;
}


/*******************************************************************************
* Function Name: MyPrototype_UpdateStatusBlock
****************************************************************************//**
*
*  Update the Completion Status Block for a Request.  The block is updated
*  with the completion code the MyPrototype_transferByteCount.  The
*  StatusBlock Pointer is set to NULL.
*
*  completionCode - status.
*
*
* \globalvars
*  MyPrototype_currentTD.pStatusBlock->status - updated by the
*    completionCode parameter.
*  MyPrototype_currentTD.pStatusBlock->length - updated.
*  MyPrototype_currentTD.pStatusBlock - cleared.
*
* \reentrant
*  No.
*
*******************************************************************************/
void MyPrototype_UpdateStatusBlock(uint8 completionCode) 
{
    if (MyPrototype_currentTD.pStatusBlock != NULL)
    {
        MyPrototype_currentTD.pStatusBlock->status = completionCode;
        MyPrototype_currentTD.pStatusBlock->length = MyPrototype_transferByteCount;
        MyPrototype_currentTD.pStatusBlock = NULL;
    }
}


/*******************************************************************************
* Function Name: MyPrototype_InitializeStatusBlock
****************************************************************************//**
*
*  Initialize the Completion Status Block for a Request.  The completion
*  code is set to USB_XFER_IDLE.
*
*  Also, initializes MyPrototype_transferByteCount.  Save some space,
*  this is the only consumer.
*
* \globalvars
*  MyPrototype_currentTD.pStatusBlock->status - set to XFER_IDLE.
*  MyPrototype_currentTD.pStatusBlock->length - cleared.
*  MyPrototype_transferByteCount - cleared.
*
* \reentrant
*  No.
*
*******************************************************************************/
void MyPrototype_InitializeStatusBlock(void) 
{
    MyPrototype_transferByteCount = 0u;
    
    if (MyPrototype_currentTD.pStatusBlock != NULL)
    {
        MyPrototype_currentTD.pStatusBlock->status = MyPrototype_XFER_IDLE;
        MyPrototype_currentTD.pStatusBlock->length = 0u;
    }
}


/* [] END OF FILE */
