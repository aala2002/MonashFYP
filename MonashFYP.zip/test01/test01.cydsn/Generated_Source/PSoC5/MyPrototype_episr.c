/***************************************************************************//**
* \file MyPrototype_episr.c
* \version 3.20
*
* \brief
*  This file contains the Data endpoint Interrupt Service Routines.
*
********************************************************************************
* \copyright
* Copyright 2008-2016, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "MyPrototype_pvt.h"
#include "MyPrototype_cydmac.h"
#include "cyapicallbacks.h"


/***************************************
* Custom Declarations
***************************************/
/* `#START CUSTOM_DECLARATIONS` Place your declaration here */

/* `#END` */


#if (MyPrototype_EP1_ISR_ACTIVE)
    /******************************************************************************
    * Function Name: MyPrototype_EP_1_ISR
    ***************************************************************************//**
    *
    *  Endpoint 1 Interrupt Service Routine
    *
    ******************************************************************************/
    CY_ISR(MyPrototype_EP_1_ISR)
    {

    #ifdef MyPrototype_EP_1_ISR_ENTRY_CALLBACK
        MyPrototype_EP_1_ISR_EntryCallback();
    #endif /* (MyPrototype_EP_1_ISR_ENTRY_CALLBACK) */

        /* `#START EP1_USER_CODE` Place your code here */

        /* `#END` */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        {
            uint8 intEn = EA;
            CyGlobalIntEnable;  /* Enable nested interrupts. */
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */
    
        MyPrototype_ClearSieEpInterruptSource(MyPrototype_SIE_INT_EP1_INTR);
            
        /* Notifies user that transfer IN or OUT transfer is completed.
        * IN endpoint: endpoint buffer can be reloaded, Host is read data.
        * OUT endpoint: data is ready to be read from endpoint buffer. 
        */
    #if (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)
        if (0u != (MyPrototype_EP[MyPrototype_EP1].addr & MyPrototype_DIR_IN))
    #endif /* (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO) */
        {
            /* Read CR0 register to clear SIE lock. */
            (void) MyPrototype_SIE_EP_BASE.sieEp[MyPrototype_EP1].epCr0;
            
            /* Toggle all endpoint types except ISOC. */
            if (MyPrototype_GET_EP_TYPE(MyPrototype_EP1) != MyPrototype_EP_TYPE_ISOC)
            {
                MyPrototype_EP[MyPrototype_EP1].epToggle ^= MyPrototype_EPX_CNT_DATA_TOGGLE;
            }

            /* EP_MANAGEMENT_DMA_AUTO (Ticket ID# 214187): For OUT endpoint this event is used to notify
            * user that DMA has completed copying data from OUT endpoint which is not completely true.
            * Because last chunk of data is being copied.
            * For CY_PSOC 3/5LP: it is acceptable as DMA is really fast.
            * For CY_PSOC4: this event is set in Arbiter interrupt (source is DMA_TERMIN).
            */
            MyPrototype_EP[MyPrototype_EP1].apiEpState = MyPrototype_EVENT_PENDING;
        }

    #if (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO))
        #if (defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
            !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
            if (MyPrototype_midi_out_ep == MyPrototype_EP1)
            {
                MyPrototype_MIDI_OUT_Service();
            }
        #endif /* (MyPrototype_ISR_SERVICE_MIDI_OUT) */
    #endif /* (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)) */
    
        /* `#START EP1_END_USER_CODE` Place your code here */

        /* `#END` */

    #ifdef MyPrototype_EP_1_ISR_EXIT_CALLBACK
        MyPrototype_EP_1_ISR_ExitCallback();
    #endif /* (MyPrototype_EP_1_ISR_EXIT_CALLBACK) */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        
            EA = intEn; /* Restore nested interrupt configuration. */
        }
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */
    }

#endif /* (MyPrototype_EP1_ISR_ACTIVE) */


#if (MyPrototype_EP2_ISR_ACTIVE)
    /*******************************************************************************
    * Function Name: MyPrototype_EP_2_ISR
    ****************************************************************************//**
    *
    *  Endpoint 2 Interrupt Service Routine.
    *
    *******************************************************************************/
    CY_ISR(MyPrototype_EP_2_ISR)
    {
    #ifdef MyPrototype_EP_2_ISR_ENTRY_CALLBACK
        MyPrototype_EP_2_ISR_EntryCallback();
    #endif /* (MyPrototype_EP_2_ISR_ENTRY_CALLBACK) */

        /* `#START EP2_USER_CODE` Place your code here */

        /* `#END` */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        {
            uint8 intEn = EA;
            CyGlobalIntEnable;  /* Enable nested interrupts. */
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */

        MyPrototype_ClearSieEpInterruptSource(MyPrototype_SIE_INT_EP2_INTR);

        /* Notifies user that transfer IN or OUT transfer is completed.
        * IN endpoint: endpoint buffer can be reloaded, Host is read data.
        * OUT endpoint: data is ready to be read from endpoint buffer. 
        */
    #if (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)
        if (0u != (MyPrototype_EP[MyPrototype_EP2].addr & MyPrototype_DIR_IN))
    #endif /* (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO) */
        {            
            /* Read CR0 register to clear SIE lock. */
            (void) MyPrototype_SIE_EP_BASE.sieEp[MyPrototype_EP2].epCr0;
            
            /* Toggle all endpoint types except ISOC. */
            if (MyPrototype_GET_EP_TYPE(MyPrototype_EP2) != MyPrototype_EP_TYPE_ISOC)
            {
                MyPrototype_EP[MyPrototype_EP2].epToggle ^= MyPrototype_EPX_CNT_DATA_TOGGLE;
            }

            /* EP_MANAGEMENT_DMA_AUTO (Ticket ID# 214187): For OUT endpoint this event is used to notify
            * user that DMA has completed copying data from OUT endpoint which is not completely true.
            * Because last chunk of data is being copied.
            * For CY_PSOC 3/5LP: it is acceptable as DMA is really fast.
            * For CY_PSOC4: this event is set in Arbiter interrupt (source is DMA_TERMIN).
            */
            MyPrototype_EP[MyPrototype_EP2].apiEpState = MyPrototype_EVENT_PENDING;
        }

    #if (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO))
        #if (defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
            !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
            if (MyPrototype_midi_out_ep == MyPrototype_EP2)
            {
                MyPrototype_MIDI_OUT_Service();
            }
        #endif /* (MyPrototype_ISR_SERVICE_MIDI_OUT) */
    #endif /* (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)) */        
    
        /* `#START EP2_END_USER_CODE` Place your code here */

        /* `#END` */

    #ifdef MyPrototype_EP_2_ISR_EXIT_CALLBACK
        MyPrototype_EP_2_ISR_ExitCallback();
    #endif /* (MyPrototype_EP_2_ISR_EXIT_CALLBACK) */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        
            EA = intEn; /* Restore nested interrupt configuration. */
        }
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */
    }
#endif /* (MyPrototype_EP2_ISR_ACTIVE) */


#if (MyPrototype_EP3_ISR_ACTIVE)
    /*******************************************************************************
    * Function Name: MyPrototype_EP_3_ISR
    ****************************************************************************//**
    *
    *  Endpoint 3 Interrupt Service Routine.
    *
    *******************************************************************************/
    CY_ISR(MyPrototype_EP_3_ISR)
    {
    #ifdef MyPrototype_EP_3_ISR_ENTRY_CALLBACK
        MyPrototype_EP_3_ISR_EntryCallback();
    #endif /* (MyPrototype_EP_3_ISR_ENTRY_CALLBACK) */

        /* `#START EP3_USER_CODE` Place your code here */

        /* `#END` */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        {
            uint8 intEn = EA;
            CyGlobalIntEnable;  /* Enable nested interrupts. */
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */

        MyPrototype_ClearSieEpInterruptSource(MyPrototype_SIE_INT_EP3_INTR);    

        /* Notifies user that transfer IN or OUT transfer is completed.
        * IN endpoint: endpoint buffer can be reloaded, Host is read data.
        * OUT endpoint: data is ready to be read from endpoint buffer. 
        */
    #if (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)
        if (0u != (MyPrototype_EP[MyPrototype_EP3].addr & MyPrototype_DIR_IN))
    #endif /* (MyPrototype_EP_MANAGEMENT_DMA_AUTO) */
        {            
            /* Read CR0 register to clear SIE lock. */
            (void) MyPrototype_SIE_EP_BASE.sieEp[MyPrototype_EP3].epCr0;

            /* Toggle all endpoint types except ISOC. */
            if (MyPrototype_GET_EP_TYPE(MyPrototype_EP3) != MyPrototype_EP_TYPE_ISOC)
            {
                MyPrototype_EP[MyPrototype_EP3].epToggle ^= MyPrototype_EPX_CNT_DATA_TOGGLE;
            }

            /* EP_MANAGEMENT_DMA_AUTO (Ticket ID# 214187): For OUT endpoint this event is used to notify
            * user that DMA has completed copying data from OUT endpoint which is not completely true.
            * Because last chunk of data is being copied.
            * For CY_PSOC 3/5LP: it is acceptable as DMA is really fast.
            * For CY_PSOC4: this event is set in Arbiter interrupt (source is DMA_TERMIN).
            */
            MyPrototype_EP[MyPrototype_EP3].apiEpState = MyPrototype_EVENT_PENDING;
        }

    #if (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO))
        #if (defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
            !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
            if (MyPrototype_midi_out_ep == MyPrototype_EP3)
            {
                MyPrototype_MIDI_OUT_Service();
            }
        #endif /* (MyPrototype_ISR_SERVICE_MIDI_OUT) */
    #endif /* (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)) */        

        /* `#START EP3_END_USER_CODE` Place your code here */

        /* `#END` */

    #ifdef MyPrototype_EP_3_ISR_EXIT_CALLBACK
        MyPrototype_EP_3_ISR_ExitCallback();
    #endif /* (MyPrototype_EP_3_ISR_EXIT_CALLBACK) */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        
            EA = intEn; /* Restore nested interrupt configuration. */
        }
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */
    }
#endif /* (MyPrototype_EP3_ISR_ACTIVE) */


#if (MyPrototype_EP4_ISR_ACTIVE)
    /*******************************************************************************
    * Function Name: MyPrototype_EP_4_ISR
    ****************************************************************************//**
    *
    *  Endpoint 4 Interrupt Service Routine.
    *
    *******************************************************************************/
    CY_ISR(MyPrototype_EP_4_ISR)
    {
    #ifdef MyPrototype_EP_4_ISR_ENTRY_CALLBACK
        MyPrototype_EP_4_ISR_EntryCallback();
    #endif /* (MyPrototype_EP_4_ISR_ENTRY_CALLBACK) */

        /* `#START EP4_USER_CODE` Place your code here */

        /* `#END` */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        {
            uint8 intEn = EA;
            CyGlobalIntEnable;  /* Enable nested interrupts. */
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */

        MyPrototype_ClearSieEpInterruptSource(MyPrototype_SIE_INT_EP4_INTR);
        
        /* Notifies user that transfer IN or OUT transfer is completed.
        * IN endpoint: endpoint buffer can be reloaded, Host is read data.
        * OUT endpoint: data is ready to read from endpoint buffer. 
        */
    #if (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)
        if (0u != (MyPrototype_EP[MyPrototype_EP4].addr & MyPrototype_DIR_IN))
    #endif /* (MyPrototype_EP_MANAGEMENT_DMA_AUTO) */
        {
            /* Read CR0 register to clear SIE lock. */
            (void) MyPrototype_SIE_EP_BASE.sieEp[MyPrototype_EP4].epCr0;

            /* Toggle all endpoint types except ISOC. */
            if (MyPrototype_GET_EP_TYPE(MyPrototype_EP4) != MyPrototype_EP_TYPE_ISOC)
            {
                MyPrototype_EP[MyPrototype_EP4].epToggle ^= MyPrototype_EPX_CNT_DATA_TOGGLE;
            }

            /* EP_MANAGEMENT_DMA_AUTO (Ticket ID# 214187): For OUT endpoint this event is used to notify
            * user that DMA has completed copying data from OUT endpoint which is not completely true.
            * Because last chunk of data is being copied.
            * For CY_PSOC 3/5LP: it is acceptable as DMA is really fast.
            * For CY_PSOC4: this event is set in Arbiter interrupt (source is DMA_TERMIN).
            */
            MyPrototype_EP[MyPrototype_EP4].apiEpState = MyPrototype_EVENT_PENDING;
        }

    #if (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO))
        #if (defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
            !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
            if(MyPrototype_midi_out_ep == MyPrototype_EP4)
            {
                MyPrototype_MIDI_OUT_Service();
            }
        #endif /* (MyPrototype_ISR_SERVICE_MIDI_OUT) */
    #endif /* (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)) */        

        /* `#START EP4_END_USER_CODE` Place your code here */

        /* `#END` */

    #ifdef MyPrototype_EP_4_ISR_EXIT_CALLBACK
        MyPrototype_EP_4_ISR_ExitCallback();
    #endif /* (MyPrototype_EP_4_ISR_EXIT_CALLBACK) */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        
            EA = intEn; /* Restore nested interrupt configuration. */
        }
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */
    }
#endif /* (MyPrototype_EP4_ISR_ACTIVE) */


#if (MyPrototype_EP5_ISR_ACTIVE)
    /*******************************************************************************
    * Function Name: MyPrototype_EP_5_ISR
    ****************************************************************************//**
    *
    *  Endpoint 5 Interrupt Service Routine
    *
    *
    *******************************************************************************/
    CY_ISR(MyPrototype_EP_5_ISR)
    {
    #ifdef MyPrototype_EP_5_ISR_ENTRY_CALLBACK
        MyPrototype_EP_5_ISR_EntryCallback();
    #endif /* (MyPrototype_EP_5_ISR_ENTRY_CALLBACK) */

        /* `#START EP5_USER_CODE` Place your code here */

        /* `#END` */

    #if (defined(MyPrototype_ENABLE_MIDI_STREAMING) && !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && \
                 MyPrototype_ISR_SERVICE_MIDI_OUT && CY_PSOC3)
        {
            uint8 intEn = EA;
            CyGlobalIntEnable;  /* Enable nested interrupts. */
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */

        MyPrototype_ClearSieEpInterruptSource(MyPrototype_SIE_INT_EP5_INTR);
    
        /* Notifies user that transfer IN or OUT transfer is completed.
        * IN endpoint: endpoint buffer can be reloaded, Host is read data.
        * OUT endpoint: data is ready to read from endpoint buffer. 
        */
    #if (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)
        if (0u != (MyPrototype_EP[MyPrototype_EP5].addr & MyPrototype_DIR_IN))
    #endif /* (MyPrototype_EP_MANAGEMENT_DMA_AUTO) */
        {            
            /* Read CR0 register to clear SIE lock. */
            (void) MyPrototype_SIE_EP_BASE.sieEp[MyPrototype_EP5].epCr0;

            /* Toggle all endpoint types except ISOC. */
            if (MyPrototype_GET_EP_TYPE(MyPrototype_EP5) != MyPrototype_EP_TYPE_ISOC)
            {
                MyPrototype_EP[MyPrototype_EP5].epToggle ^= MyPrototype_EPX_CNT_DATA_TOGGLE;
            }

            /* EP_MANAGEMENT_DMA_AUTO (Ticket ID# 214187): For OUT endpoint this event is used to notify
            * user that DMA has completed copying data from OUT endpoint which is not completely true.
            * Because last chunk of data is being copied.
            * For CY_PSOC 3/5LP: it is acceptable as DMA is really fast.
            * For CY_PSOC4: this event is set in Arbiter interrupt (source is DMA_TERMIN).
            */
            MyPrototype_EP[MyPrototype_EP5].apiEpState = MyPrototype_EVENT_PENDING;
        }

    #if (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO))        
        #if (defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
            !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
            if (MyPrototype_midi_out_ep == MyPrototype_EP5)
            {
                MyPrototype_MIDI_OUT_Service();
            }
        #endif /* (MyPrototype_ISR_SERVICE_MIDI_OUT) */
    #endif /* (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)) */

        /* `#START EP5_END_USER_CODE` Place your code here */

        /* `#END` */

    #ifdef MyPrototype_EP_5_ISR_EXIT_CALLBACK
        MyPrototype_EP_5_ISR_ExitCallback();
    #endif /* (MyPrototype_EP_5_ISR_EXIT_CALLBACK) */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        
            EA = intEn; /* Restore nested interrupt configuration. */
        }
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */
    }
#endif /* (MyPrototype_EP5_ISR_ACTIVE) */


#if (MyPrototype_EP6_ISR_ACTIVE)
    /*******************************************************************************
    * Function Name: MyPrototype_EP_6_ISR
    ****************************************************************************//**
    *
    *  Endpoint 6 Interrupt Service Routine.
    *
    *
    *******************************************************************************/
    CY_ISR(MyPrototype_EP_6_ISR)
    {
    #ifdef MyPrototype_EP_6_ISR_ENTRY_CALLBACK
        MyPrototype_EP_6_ISR_EntryCallback();
    #endif /* (MyPrototype_EP_6_ISR_ENTRY_CALLBACK) */

        /* `#START EP6_USER_CODE` Place your code here */

        /* `#END` */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        {
            uint8 intEn = EA;
            CyGlobalIntEnable;  /* Enable nested interrupts. */
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */

        MyPrototype_ClearSieEpInterruptSource(MyPrototype_SIE_INT_EP6_INTR);
        
        /* Notifies user that transfer IN or OUT transfer is completed.
        * IN endpoint: endpoint buffer can be reloaded, Host is read data.
        * OUT endpoint: data is ready to read from endpoint buffer. 
        */
    #if (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)
        if (0u != (MyPrototype_EP[MyPrototype_EP6].addr & MyPrototype_DIR_IN))
    #endif /* (MyPrototype_EP_MANAGEMENT_DMA_AUTO) */
        {
            /* Read CR0 register to clear SIE lock. */
            (void) MyPrototype_SIE_EP_BASE.sieEp[MyPrototype_EP6].epCr0;

            /* Toggle all endpoint types except ISOC. */
            if (MyPrototype_GET_EP_TYPE(MyPrototype_EP6) != MyPrototype_EP_TYPE_ISOC)
            {
                MyPrototype_EP[MyPrototype_EP6].epToggle ^= MyPrototype_EPX_CNT_DATA_TOGGLE;
            }
            
            /* EP_MANAGEMENT_DMA_AUTO (Ticket ID# 214187): For OUT endpoint this event is used to notify
            * user that DMA has completed copying data from OUT endpoint which is not completely true.
            * Because last chunk of data is being copied.
            * For CY_PSOC 3/5LP: it is acceptable as DMA is really fast.
            * For CY_PSOC4: this event is set in Arbiter interrupt (source is DMA_TERMIN).
            */
            MyPrototype_EP[MyPrototype_EP6].apiEpState = MyPrototype_EVENT_PENDING;
        }

    #if (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO))
        #if (defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
            !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
            if (MyPrototype_midi_out_ep == MyPrototype_EP6)
            {
                MyPrototype_MIDI_OUT_Service();
            }
        #endif /* (MyPrototype_ISR_SERVICE_MIDI_OUT) */
    #endif /* (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)) */

        /* `#START EP6_END_USER_CODE` Place your code here */

        /* `#END` */

    #ifdef MyPrototype_EP_6_ISR_EXIT_CALLBACK
        MyPrototype_EP_6_ISR_ExitCallback();
    #endif /* (MyPrototype_EP_6_ISR_EXIT_CALLBACK) */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        
            EA = intEn; /* Restore nested interrupt configuration. */
        }
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */
    }
#endif /* (MyPrototype_EP6_ISR_ACTIVE) */


#if (MyPrototype_EP7_ISR_ACTIVE)
    /*******************************************************************************
    * Function Name: MyPrototype_EP_7_ISR
    ****************************************************************************//**
    *
    *  Endpoint 7 Interrupt Service Routine.
    *
    *
    *******************************************************************************/
    CY_ISR(MyPrototype_EP_7_ISR)
    {
    #ifdef MyPrototype_EP_7_ISR_ENTRY_CALLBACK
        MyPrototype_EP_7_ISR_EntryCallback();
    #endif /* (MyPrototype_EP_7_ISR_ENTRY_CALLBACK) */

        /* `#START EP7_USER_CODE` Place your code here */

        /* `#END` */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        {
            uint8 intEn = EA;
            CyGlobalIntEnable;  /* Enable nested interrupts. */
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */
    
        MyPrototype_ClearSieEpInterruptSource(MyPrototype_SIE_INT_EP7_INTR);
        
        /* Notifies user that transfer IN or OUT transfer is completed.
        * IN endpoint: endpoint buffer can be reloaded, Host is read data.
        * OUT endpoint: data is ready to read from endpoint buffer. 
        */
    #if (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)
        if (0u != (MyPrototype_EP[MyPrototype_EP7].addr & MyPrototype_DIR_IN))
    #endif /* (MyPrototype_EP_MANAGEMENT_DMA_AUTO) */
        {           
            /* Read CR0 register to clear SIE lock. */
            (void) MyPrototype_SIE_EP_BASE.sieEp[MyPrototype_EP7].epCr0;

            /* Toggle all endpoint types except ISOC. */
            if (MyPrototype_GET_EP_TYPE(MyPrototype_EP7) != MyPrototype_EP_TYPE_ISOC)
            {
                MyPrototype_EP[MyPrototype_EP7].epToggle ^= MyPrototype_EPX_CNT_DATA_TOGGLE;
            }
            
            /* EP_MANAGEMENT_DMA_AUTO (Ticket ID# 214187): For OUT endpoint this event is used to notify
            * user that DMA has completed copying data from OUT endpoint which is not completely true.
            * Because last chunk of data is being copied.
            * For CY_PSOC 3/5LP: it is acceptable as DMA is really fast.
            * For CY_PSOC4: this event is set in Arbiter interrupt (source is DMA_TERMIN).
            */
            MyPrototype_EP[MyPrototype_EP7].apiEpState = MyPrototype_EVENT_PENDING;
        }


    #if (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO))
        #if (defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
            !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
            if(MyPrototype_midi_out_ep == MyPrototype_EP7)
            {
                MyPrototype_MIDI_OUT_Service();
            }
        #endif /* (MyPrototype_ISR_SERVICE_MIDI_OUT) */
    #endif /* (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)) */

        /* `#START EP7_END_USER_CODE` Place your code here */

        /* `#END` */

    #ifdef MyPrototype_EP_7_ISR_EXIT_CALLBACK
        MyPrototype_EP_7_ISR_ExitCallback();
    #endif /* (MyPrototype_EP_7_ISR_EXIT_CALLBACK) */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        
            EA = intEn; /* Restore nested interrupt configuration. */
        }
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */
    }
#endif /* (MyPrototype_EP7_ISR_ACTIVE) */


#if (MyPrototype_EP8_ISR_ACTIVE)
    /*******************************************************************************
    * Function Name: MyPrototype_EP_8_ISR
    ****************************************************************************//**
    *
    *  Endpoint 8 Interrupt Service Routine
    *
    *
    *******************************************************************************/
    CY_ISR(MyPrototype_EP_8_ISR)
    {
    #ifdef MyPrototype_EP_8_ISR_ENTRY_CALLBACK
        MyPrototype_EP_8_ISR_EntryCallback();
    #endif /* (MyPrototype_EP_8_ISR_ENTRY_CALLBACK) */

        /* `#START EP8_USER_CODE` Place your code here */

        /* `#END` */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        {
            uint8 intEn = EA;
            CyGlobalIntEnable;  /* Enable nested interrupts. */
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */

        MyPrototype_ClearSieEpInterruptSource(MyPrototype_SIE_INT_EP8_INTR);
        
        /* Notifies user that transfer IN or OUT transfer is completed.
        * IN endpoint: endpoint buffer can be reloaded, Host is read data.
        * OUT endpoint: data is ready to read from endpoint buffer. 
        */
    #if (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)
        if (0u != (MyPrototype_EP[MyPrototype_EP8].addr & MyPrototype_DIR_IN))
    #endif /* (MyPrototype_EP_MANAGEMENT_DMA_AUTO) */
        {
            /* Read CR0 register to clear SIE lock. */
            (void) MyPrototype_SIE_EP_BASE.sieEp[MyPrototype_EP8].epCr0;

            /* Toggle all endpoint types except ISOC. */
            if (MyPrototype_GET_EP_TYPE(MyPrototype_EP8) != MyPrototype_EP_TYPE_ISOC)
            {
                MyPrototype_EP[MyPrototype_EP8].epToggle ^= MyPrototype_EPX_CNT_DATA_TOGGLE;
            }

            /* EP_MANAGEMENT_DMA_AUTO (Ticket ID# 214187): For OUT endpoint this event is used to notify
            * user that DMA has completed copying data from OUT endpoint which is not completely true.
            * Because last chunk of data is being copied.
            * For CY_PSOC 3/5LP: it is acceptable as DMA is really fast.
            * For CY_PSOC4: this event is set in Arbiter interrupt (source is DMA_TERMIN).
            */
            MyPrototype_EP[MyPrototype_EP8].apiEpState = MyPrototype_EVENT_PENDING;
        }

    #if (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO))
        #if (defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
            !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
            if (MyPrototype_midi_out_ep == MyPrototype_EP8)
            {
                MyPrototype_MIDI_OUT_Service();
            }
        #endif /* (MyPrototype_ISR_SERVICE_MIDI_OUT) */
    #endif /* (!(CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)) */

        /* `#START EP8_END_USER_CODE` Place your code here */

        /* `#END` */

    #ifdef MyPrototype_EP_8_ISR_EXIT_CALLBACK
        MyPrototype_EP_8_ISR_ExitCallback();
    #endif /* (MyPrototype_EP_8_ISR_EXIT_CALLBACK) */

    #if (CY_PSOC3 && defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
        !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
        
            EA = intEn; /* Restore nested interrupt configuration. */
        }
    #endif /* (CY_PSOC3 && MyPrototype_ISR_SERVICE_MIDI_OUT) */
    }
#endif /* (MyPrototype_EP8_ISR_ACTIVE) */


#if (MyPrototype_SOF_ISR_ACTIVE)
    /*******************************************************************************
    * Function Name: MyPrototype_SOF_ISR
    ****************************************************************************//**
    *
    *  Start of Frame Interrupt Service Routine.
    *
    *
    *******************************************************************************/
    CY_ISR(MyPrototype_SOF_ISR)
    {
    #ifdef MyPrototype_SOF_ISR_ENTRY_CALLBACK
        MyPrototype_SOF_ISR_EntryCallback();
    #endif /* (MyPrototype_SOF_ISR_ENTRY_CALLBACK) */

        /* `#START SOF_USER_CODE` Place your code here */

        /* `#END` */

        MyPrototype_ClearSieInterruptSource(MyPrototype_INTR_SIE_SOF_INTR);

    #ifdef MyPrototype_SOF_ISR_EXIT_CALLBACK
        MyPrototype_SOF_ISR_ExitCallback();
    #endif /* (MyPrototype_SOF_ISR_EXIT_CALLBACK) */
    }
#endif /* (MyPrototype_SOF_ISR_ACTIVE) */


#if (MyPrototype_BUS_RESET_ISR_ACTIVE)
/*******************************************************************************
* Function Name: MyPrototype_BUS_RESET_ISR
****************************************************************************//**
*
*  USB Bus Reset Interrupt Service Routine.  Calls _Start with the same
*  parameters as the last USER call to _Start
*
*
*******************************************************************************/
CY_ISR(MyPrototype_BUS_RESET_ISR)
{
#ifdef MyPrototype_BUS_RESET_ISR_ENTRY_CALLBACK
    MyPrototype_BUS_RESET_ISR_EntryCallback();
#endif /* (MyPrototype_BUS_RESET_ISR_ENTRY_CALLBACK) */

    /* `#START BUS_RESET_USER_CODE` Place your code here */

    /* `#END` */

    MyPrototype_ClearSieInterruptSource(MyPrototype_INTR_SIE_BUS_RESET_INTR);

    MyPrototype_ReInitComponent();

#ifdef MyPrototype_BUS_RESET_ISR_EXIT_CALLBACK
    MyPrototype_BUS_RESET_ISR_ExitCallback();
#endif /* (MyPrototype_BUS_RESET_ISR_EXIT_CALLBACK) */
}
#endif /* (MyPrototype_BUS_RESET_ISR_ACTIVE) */


#if (MyPrototype_LPM_ACTIVE)
/***************************************************************************
* Function Name: MyPrototype_INTR_LPM_ISR
************************************************************************//**
*
*   Interrupt Service Routine for LPM of the interrupt sources.
*
*
***************************************************************************/
CY_ISR(MyPrototype_LPM_ISR)
{
#ifdef MyPrototype_LPM_ISR_ENTRY_CALLBACK
    MyPrototype_LPM_ISR_EntryCallback();
#endif /* (MyPrototype_LPM_ISR_ENTRY_CALLBACK) */

    /* `#START LPM_BEGIN_USER_CODE` Place your code here */

    /* `#END` */

    MyPrototype_ClearSieInterruptSource(MyPrototype_INTR_SIE_LPM_INTR);

    /* `#START LPM_END_USER_CODE` Place your code here */

    /* `#END` */

#ifdef MyPrototype_LPM_ISR_EXIT_CALLBACK
    MyPrototype_LPM_ISR_ExitCallback();
#endif /* (MyPrototype_LPM_ISR_EXIT_CALLBACK) */
}
#endif /* (MyPrototype_LPM_ACTIVE) */


#if (MyPrototype_EP_MANAGEMENT_DMA && MyPrototype_ARB_ISR_ACTIVE)
    /***************************************************************************
    * Function Name: MyPrototype_ARB_ISR
    ************************************************************************//**
    *
    *  Arbiter Interrupt Service Routine.
    *
    *
    ***************************************************************************/
    CY_ISR(MyPrototype_ARB_ISR)
    {
        uint8 arbIntrStatus;
        uint8 epStatus;
        uint8 ep = MyPrototype_EP1;

    #ifdef MyPrototype_ARB_ISR_ENTRY_CALLBACK
        MyPrototype_ARB_ISR_EntryCallback();
    #endif /* (MyPrototype_ARB_ISR_ENTRY_CALLBACK) */

        /* `#START ARB_BEGIN_USER_CODE` Place your code here */

        /* `#END` */

        /* Get pending ARB interrupt sources. */
        arbIntrStatus = MyPrototype_ARB_INT_SR_REG;

        while (0u != arbIntrStatus)
        {
            /* Check which EP is interrupt source. */
            if (0u != (arbIntrStatus & 0x01u))
            {
                /* Get endpoint enable interrupt sources. */
                epStatus = (MyPrototype_ARB_EP_BASE.arbEp[ep].epSr & MyPrototype_ARB_EP_BASE.arbEp[ep].epIntEn);

                /* Handle IN endpoint buffer full event: happens only once when endpoint buffer is loaded. */
                if (0u != (epStatus & MyPrototype_ARB_EPX_INT_IN_BUF_FULL))
                {
                    if (0u != (MyPrototype_EP[ep].addr & MyPrototype_DIR_IN))
                    {
                        /* Clear data ready status. */
                        MyPrototype_ARB_EP_BASE.arbEp[ep].epCfg &= (uint8) ~MyPrototype_ARB_EPX_CFG_IN_DATA_RDY;

                    #if (CY_PSOC3 || CY_PSOC5LP)
                        #if (MyPrototype_EP_MANAGEMENT_DMA_AUTO && (MyPrototype_EP_DMA_AUTO_OPT == 0u))
                            /* Set up common area DMA with rest of data. */
                            if(MyPrototype_inLength[ep] > MyPrototype_DMA_BYTES_PER_BURST)
                            {
                                MyPrototype_LoadNextInEP(ep, 0u);
                            }
                            else
                            {
                                MyPrototype_inBufFull[ep] = 1u;
                            }
                        #endif /* (MyPrototype_EP_MANAGEMENT_DMA_AUTO && (MyPrototype_EP_DMA_AUTO_OPT == 0u)) */
                    #endif /* (CY_PSOC3 || CY_PSOC5LP) */

                        /* Arm IN endpoint. */
                        MyPrototype_SIE_EP_BASE.sieEp[ep].epCr0 = MyPrototype_EP[ep].epMode;

                    #if (defined(MyPrototype_ENABLE_MIDI_STREAMING) && MyPrototype_ISR_SERVICE_MIDI_IN)
                        if (ep == MyPrototype_midi_in_ep)
                        {
                            /* Clear MIDI input pointer. */
                            MyPrototype_midiInPointer = 0u;
                        }
                    #endif /* (MyPrototype_ENABLE_MIDI_STREAMING) */
                    }
                }

            #if (MyPrototype_EP_MANAGEMENT_DMA_MANUAL)
                /* Handle DMA completion event for OUT endpoints. */
                if (0u != (epStatus & MyPrototype_ARB_EPX_SR_DMA_GNT))
                {
                    if (0u == (MyPrototype_EP[ep].addr & MyPrototype_DIR_IN))
                    {
                        /* Notify user that data has been copied from endpoint buffer. */
                        MyPrototype_EP[ep].apiEpState = MyPrototype_NO_EVENT_PENDING;

                        /* DMA done coping data: OUT endpoint has to be re-armed by user. */
                    }
                }
            #endif /* (MyPrototype_EP_MANAGEMENT_DMA_MANUAL) */

            #if (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO)
                /* Handle DMA completion event for OUT endpoints. */
                if (0u != (epStatus & MyPrototype_ARB_EPX_INT_DMA_TERMIN))
                {
                    uint32 channelNum = MyPrototype_DmaChan[ep];

                    /* Restore burst counter for endpoint. */
                    MyPrototype_DmaEpBurstCnt[ep] = MyPrototype_DMA_GET_BURST_CNT(MyPrototype_DmaEpBurstCntBackup[ep]);

                    /* Disable DMA channel to restore descriptor configuration. The on-going transfer is aborted. */
                    MyPrototype_CyDmaChDisable(channelNum);

                    /* Generate DMA tr_out signal to notify USB IP that DMA is done. This signal is not generated
                    * when transfer was aborted (it occurs when host writes less bytes than buffer size).
                    */
                    MyPrototype_CyDmaTriggerOut(MyPrototype_DmaBurstEndOut[ep]);

                    /* Restore destination address for output endpoint. */
                    MyPrototype_CyDmaSetDstAddress(channelNum, MyPrototype_DMA_DESCR0, (void*) ((uint32) MyPrototype_DmaEpBufferAddrBackup[ep]));
                    MyPrototype_CyDmaSetDstAddress(channelNum, MyPrototype_DMA_DESCR1, (void*) ((uint32) MyPrototype_DmaEpBufferAddrBackup[ep] +
                                                                                                                   MyPrototype_DMA_BYTES_PER_BURST));

                    /* Restore number of data elements to transfer which was adjusted for last burst. */
                    if (0u != (MyPrototype_DmaEpLastBurstEl[ep] & MyPrototype_DMA_DESCR_REVERT))
                    {
                        MyPrototype_CyDmaSetNumDataElements(channelNum, (MyPrototype_DmaEpLastBurstEl[ep] >> MyPrototype_DMA_DESCR_SHIFT),
                                                                             MyPrototype_DMA_GET_MAX_ELEM_PER_BURST(MyPrototype_DmaEpLastBurstEl[ep]));
                    }

                    /* Validate descriptor 0 and 1 (also reset current state). Command to start with descriptor 0. */
                    MyPrototype_CyDmaValidateDescriptor(channelNum, MyPrototype_DMA_DESCR0);
                    if (MyPrototype_DmaEpBurstCntBackup[ep] > 1u)
                    {
                        MyPrototype_CyDmaValidateDescriptor(channelNum, MyPrototype_DMA_DESCR1);
                    }
                    MyPrototype_CyDmaSetDescriptor0Next(channelNum);

                    /* Enable DMA channel: configuration complete. */
                    MyPrototype_CyDmaChEnable(channelNum);
                    
                    
                    /* Read CR0 register to clear SIE lock. */
                    (void) MyPrototype_SIE_EP_BASE.sieEp[ep].epCr0;
                    
                    /* Toggle all endpoint types except ISOC. */
                    if (MyPrototype_GET_EP_TYPE(ep) != MyPrototype_EP_TYPE_ISOC)
                    {
                        MyPrototype_EP[ep].epToggle ^= MyPrototype_EPX_CNT_DATA_TOGGLE;
                    }
            
                    /* Notify user that data has been copied from endpoint buffer. */
                    MyPrototype_EP[ep].apiEpState = MyPrototype_EVENT_PENDING;
                    
                #if (defined(MyPrototype_ENABLE_MIDI_STREAMING) && \
                    !defined(MyPrototype_MAIN_SERVICE_MIDI_OUT) && MyPrototype_ISR_SERVICE_MIDI_OUT)
                    if (MyPrototype_midi_out_ep == ep)
                    {
                        MyPrototype_MIDI_OUT_Service();
                    }
                #endif /* (MyPrototype_ISR_SERVICE_MIDI_OUT) */
                }
            #endif /* (CY_PSOC4 && MyPrototype_EP_MANAGEMENT_DMA_AUTO) */


                /* `#START ARB_USER_CODE` Place your code here for handle Buffer Underflow/Overflow */

                /* `#END` */

            #ifdef MyPrototype_ARB_ISR_CALLBACK
                MyPrototype_ARB_ISR_Callback(ep, epStatus);
            #endif /* (MyPrototype_ARB_ISR_CALLBACK) */

                /* Clear serviced endpoint interrupt sources. */
                MyPrototype_ARB_EP_BASE.arbEp[ep].epSr = epStatus;
            }

            ++ep;
            arbIntrStatus >>= 1u;
        }

        /* `#START ARB_END_USER_CODE` Place your code here */

        /* `#END` */

    #ifdef MyPrototype_ARB_ISR_EXIT_CALLBACK
        MyPrototype_ARB_ISR_ExitCallback();
    #endif /* (MyPrototype_ARB_ISR_EXIT_CALLBACK) */
    }

#endif /*  (MyPrototype_ARB_ISR_ACTIVE && MyPrototype_EP_MANAGEMENT_DMA) */


#if (MyPrototype_EP_MANAGEMENT_DMA_AUTO)
#if (CY_PSOC4)

    /******************************************************************************
    * Function Name: MyPrototype_EPxDmaDone
    ***************************************************************************//**
    *
    * \internal
    *  Endpoint  DMA Done Interrupt Service Routine basic function .
    *  
    *  \param dmaCh
    *  number of DMA channel
    *  
    *  \param ep
    *  number of USB end point
    *  
    *  \param dmaDone
    *  transfer completion flag
    *  
    *  \return
    *   updated transfer completion flag
    *
    ******************************************************************************/
    CY_INLINE static void MyPrototype_EPxDmaDone(uint8 dmaCh, uint8 ep)
    {
        uint32 nextAddr;

        /* Manage data elements which remain to transfer. */
        if (0u != MyPrototype_DmaEpBurstCnt[ep])
        {
            if(MyPrototype_DmaEpBurstCnt[ep] <= 2u)
            {
                /* Adjust length of last burst. */
                MyPrototype_CyDmaSetNumDataElements(dmaCh,
                                                    ((uint32) MyPrototype_DmaEpLastBurstEl[ep] >> MyPrototype_DMA_DESCR_SHIFT),
                                                    ((uint32) MyPrototype_DmaEpLastBurstEl[ep] &  MyPrototype_DMA_BURST_BYTES_MASK));
            }
            

            /* Advance source for input endpoint or destination for output endpoint. */
            if (0u != (MyPrototype_EP[ep].addr & MyPrototype_DIR_IN))
            {
                /* Change source for descriptor 0. */
                nextAddr = (uint32) MyPrototype_CyDmaGetSrcAddress(dmaCh, MyPrototype_DMA_DESCR0);
                nextAddr += (2u * MyPrototype_DMA_BYTES_PER_BURST);
                MyPrototype_CyDmaSetSrcAddress(dmaCh, MyPrototype_DMA_DESCR0, (void *) nextAddr);

                /* Change source for descriptor 1. */
                nextAddr += MyPrototype_DMA_BYTES_PER_BURST;
                MyPrototype_CyDmaSetSrcAddress(dmaCh, MyPrototype_DMA_DESCR1, (void *) nextAddr);
            }
            else
            {
                /* Change destination for descriptor 0. */
                nextAddr  = (uint32) MyPrototype_CyDmaGetDstAddress(dmaCh, MyPrototype_DMA_DESCR0);
                nextAddr += (2u * MyPrototype_DMA_BYTES_PER_BURST);
                MyPrototype_CyDmaSetDstAddress(dmaCh, MyPrototype_DMA_DESCR0, (void *) nextAddr);

                /* Change destination for descriptor 1. */
                nextAddr += MyPrototype_DMA_BYTES_PER_BURST;
                MyPrototype_CyDmaSetDstAddress(dmaCh, MyPrototype_DMA_DESCR1, (void *) nextAddr);
            }

            /* Enable DMA to execute transfer as it was disabled because there were no valid descriptor. */
            MyPrototype_CyDmaValidateDescriptor(dmaCh, MyPrototype_DMA_DESCR0);
            
            --MyPrototype_DmaEpBurstCnt[ep];
            if (0u != MyPrototype_DmaEpBurstCnt[ep])
            {
                MyPrototype_CyDmaValidateDescriptor(dmaCh, MyPrototype_DMA_DESCR1);
                --MyPrototype_DmaEpBurstCnt[ep];
            }
            
            MyPrototype_CyDmaChEnable (dmaCh);
            MyPrototype_CyDmaTriggerIn(MyPrototype_DmaReqOut[ep]);
        }
        else
        {
            /* No data to transfer. False DMA trig. Ignore.  */
        }

    }

    #if (MyPrototype_DMA1_ACTIVE)
        /******************************************************************************
        * Function Name: MyPrototype_EP1_DMA_DONE_ISR
        ***************************************************************************//**
        *
        *  Endpoint 1 DMA Done Interrupt Service Routine.
        *
        *
        ******************************************************************************/
        void MyPrototype_EP1_DMA_DONE_ISR(void)
        {

            MyPrototype_EPxDmaDone((uint8)MyPrototype_EP1_DMA_CH,
                                                  MyPrototype_EP1);
                
        }
    #endif /* (MyPrototype_DMA1_ACTIVE) */


    #if (MyPrototype_DMA2_ACTIVE)
        /******************************************************************************
        * Function Name: MyPrototype_EP2_DMA_DONE_ISR
        ***************************************************************************//**
        *
        *  Endpoint 2 DMA Done Interrupt Service Routine.
        *
        *
        ******************************************************************************/
        void MyPrototype_EP2_DMA_DONE_ISR(void)
        {

            MyPrototype_EPxDmaDone((uint8)MyPrototype_EP2_DMA_CH,
                                                  MyPrototype_EP2);
        }
    #endif /* (MyPrototype_DMA2_ACTIVE) */


    #if (MyPrototype_DMA3_ACTIVE)
        /******************************************************************************
        * Function Name: MyPrototype_EP3_DMA_DONE_ISR
        ***************************************************************************//**
        *
        *  Endpoint 3 DMA Done Interrupt Service Routine.
        *
        *
        ******************************************************************************/
        void MyPrototype_EP3_DMA_DONE_ISR(void)
        {

            MyPrototype_EPxDmaDone((uint8)MyPrototype_EP3_DMA_CH,
                                                  MyPrototype_EP3);
        }
    #endif /* (MyPrototype_DMA3_ACTIVE) */


    #if (MyPrototype_DMA4_ACTIVE)
        /******************************************************************************
        * Function Name: MyPrototype_EP4_DMA_DONE_ISR
        ***************************************************************************//**
        *
        *  Endpoint 4 DMA Done Interrupt Service Routine.
        *
        *
        ******************************************************************************/
        void MyPrototype_EP4_DMA_DONE_ISR(void)
        {

            MyPrototype_EPxDmaDone((uint8)MyPrototype_EP4_DMA_CH,
                                                  MyPrototype_EP4);
        }
    #endif /* (MyPrototype_DMA4_ACTIVE) */


    #if (MyPrototype_DMA5_ACTIVE)
        /******************************************************************************
        * Function Name: MyPrototype_EP5_DMA_DONE_ISR
        ***************************************************************************//**
        *
        *  Endpoint 5 DMA Done Interrupt Service Routine.
        *
        *
        ******************************************************************************/
        void MyPrototype_EP5_DMA_DONE_ISR(void)
        {

            MyPrototype_EPxDmaDone((uint8)MyPrototype_EP5_DMA_CH,
                                                  MyPrototype_EP5);
        }
    #endif /* (MyPrototype_DMA5_ACTIVE) */


    #if (MyPrototype_DMA6_ACTIVE)
        /******************************************************************************
        * Function Name: MyPrototype_EP6_DMA_DONE_ISR
        ***************************************************************************//**
        *
        *  Endpoint 6 DMA Done Interrupt Service Routine.
        *
        *
        ******************************************************************************/
        void MyPrototype_EP6_DMA_DONE_ISR(void)
        {

            MyPrototype_EPxDmaDone((uint8)MyPrototype_EP6_DMA_CH,
                                                  MyPrototype_EP6);
        }
    #endif /* (MyPrototype_DMA6_ACTIVE) */


    #if (MyPrototype_DMA7_ACTIVE)
        /******************************************************************************
        * Function Name: MyPrototype_EP7_DMA_DONE_ISR
        ***************************************************************************//**
        *
        *  Endpoint 7 DMA Done Interrupt Service Routine.
        *
        *
        ******************************************************************************/
        void MyPrototype_EP7_DMA_DONE_ISR(void)
        {

            MyPrototype_EPxDmaDone((uint8)MyPrototype_EP7_DMA_CH,
                                                  MyPrototype_EP7);
        }
    #endif /* (MyPrototype_DMA7_ACTIVE) */


    #if (MyPrototype_DMA8_ACTIVE)
        /******************************************************************************
        * Function Name: MyPrototype_EP8_DMA_DONE_ISR
        ***************************************************************************//**
        *
        *  Endpoint 8 DMA Done Interrupt Service Routine.
        *
        *
        ******************************************************************************/
        void MyPrototype_EP8_DMA_DONE_ISR(void)
        {

            MyPrototype_EPxDmaDone((uint8)MyPrototype_EP8_DMA_CH,
                                                  MyPrototype_EP8);
        }
    #endif /* (MyPrototype_DMA8_ACTIVE) */


#else
    #if (MyPrototype_EP_DMA_AUTO_OPT == 0u)
        /******************************************************************************
        * Function Name: MyPrototype_EP_DMA_DONE_ISR
        ***************************************************************************//**
        *
        *  DMA Done Interrupt Service Routine.
        *
        *
        ******************************************************************************/
        CY_ISR(MyPrototype_EP_DMA_DONE_ISR)
        {
            uint8 int8Status;
            uint8 int17Status;
            uint8 ep_status;
            uint8 ep = MyPrototype_EP1;

        #ifdef MyPrototype_EP_DMA_DONE_ISR_ENTRY_CALLBACK
            MyPrototype_EP_DMA_DONE_ISR_EntryCallback();
        #endif /* (MyPrototype_EP_DMA_DONE_ISR_ENTRY_CALLBACK) */

            /* `#START EP_DMA_DONE_BEGIN_USER_CODE` Place your code here */

            /* `#END` */

            /* Read clear on read status register with EP source of interrupt. */
            int17Status = MyPrototype_EP17_DMA_Done_SR_Read() & MyPrototype_EP17_SR_MASK;
            int8Status  = MyPrototype_EP8_DMA_Done_SR_Read()  & MyPrototype_EP8_SR_MASK;

            while (int8Status != 0u)
            {
                while (int17Status != 0u)
                {
                    if ((int17Status & 1u) != 0u)  /* If EpX interrupt present. */
                    {
                        /* Read Endpoint Status Register. */
                        ep_status = MyPrototype_ARB_EP_BASE.arbEp[ep].epSr;

                        if ((0u == (ep_status & MyPrototype_ARB_EPX_SR_IN_BUF_FULL)) &&
                            (0u ==MyPrototype_inBufFull[ep]))
                        {
                            /* `#START EP_DMA_DONE_USER_CODE` Place your code here */

                            /* `#END` */

                        #ifdef MyPrototype_EP_DMA_DONE_ISR_CALLBACK
                            MyPrototype_EP_DMA_DONE_ISR_Callback();
                        #endif /* (MyPrototype_EP_DMA_DONE_ISR_CALLBACK) */

                            /* Transfer again 2 last bytes into pre-fetch endpoint area. */
                            MyPrototype_ARB_EP_BASE.arbEp[ep].rwWaMsb = 0u;
                            MyPrototype_ARB_EP_BASE.arbEp[ep].rwWa = (MyPrototype_DMA_BYTES_PER_BURST * ep) - MyPrototype_DMA_BYTES_REPEAT;
                            MyPrototype_LoadNextInEP(ep, 1u);

                            /* Set Data ready status to generate DMA request. */
                            MyPrototype_ARB_EP_BASE.arbEp[ep].epCfg |= MyPrototype_ARB_EPX_CFG_IN_DATA_RDY;
                        }
                    }

                    ep++;
                    int17Status >>= 1u;
                }

                int8Status >>= 1u;

                if (int8Status != 0u)
                {
                    /* Prepare pointer for EP8. */
                    ep = MyPrototype_EP8;
                    int17Status = int8Status & 0x01u;
                }
            }

            /* `#START EP_DMA_DONE_END_USER_CODE` Place your code here */

            /* `#END` */

    #ifdef MyPrototype_EP_DMA_DONE_ISR_EXIT_CALLBACK
        MyPrototype_EP_DMA_DONE_ISR_ExitCallback();
    #endif /* (MyPrototype_EP_DMA_DONE_ISR_EXIT_CALLBACK) */
        }
    #endif /* (MyPrototype_EP_DMA_AUTO_OPT == 0u) */
#endif /* (CY_PSOC4) */
#endif /* (MyPrototype_EP_MANAGEMENT_DMA_AUTO) */


#if (CY_PSOC4)
    /***************************************************************************
    * Function Name: MyPrototype_IntrHandler
    ************************************************************************//**
    *
    *   Interrupt handler for Hi/Mid/Low ISRs.
    *
    *  regCause - The cause register of interrupt. One of the three variants:
    *       MyPrototype_INTR_CAUSE_LO_REG - Low interrupts.
    *       MyPrototype_INTR_CAUSE_MED_REG - Med interrupts.
    *       MyPrototype_INTR_CAUSE_HI_REG - - High interrupts.
    *
    *
    ***************************************************************************/
    CY_INLINE static void MyPrototype_IntrHandler(uint32 intrCause)
    {
        /* Array of pointers to component interrupt handlers. */
        static const cyisraddress MyPrototype_isrCallbacks[] =
        {

        };

        uint32 cbIdx = 0u;

        /* Check arbiter interrupt source first. */
        if (0u != (intrCause & MyPrototype_INTR_CAUSE_ARB_INTR))
        {
            MyPrototype_isrCallbacks[MyPrototype_ARB_EP_INTR_NUM]();
        }

        /* Check all other interrupt sources (except arbiter and resume). */
        intrCause = (intrCause  & MyPrototype_INTR_CAUSE_CTRL_INTR_MASK) |
                    ((intrCause & MyPrototype_INTR_CAUSE_EP1_8_INTR_MASK) >>
                                  MyPrototype_INTR_CAUSE_EP_INTR_SHIFT);

        /* Call interrupt handlers for active interrupt sources. */
        while (0u != intrCause)
        {
            if (0u != (intrCause & 0x1u))
            {
                 MyPrototype_isrCallbacks[cbIdx]();
            }

            intrCause >>= 1u;
            ++cbIdx;
        }
    }


    /***************************************************************************
    * Function Name: MyPrototype_INTR_HI_ISR
    ************************************************************************//**
    *
    *   Interrupt Service Routine for the high group of the interrupt sources.
    *
    *
    ***************************************************************************/
    CY_ISR(MyPrototype_INTR_HI_ISR)
    {
        MyPrototype_IntrHandler(MyPrototype_INTR_CAUSE_HI_REG);
    }

    /***************************************************************************
    * Function Name: MyPrototype_INTR_MED_ISR
    ************************************************************************//**
    *
    *   Interrupt Service Routine for the medium group of the interrupt sources.
    *
    *
    ***************************************************************************/
    CY_ISR(MyPrototype_INTR_MED_ISR)
    {
       MyPrototype_IntrHandler(MyPrototype_INTR_CAUSE_MED_REG);
    }

    /***************************************************************************
    * Function Name: MyPrototype_INTR_LO_ISR
    ************************************************************************//**
    *
    *   Interrupt Service Routine for the low group of the interrupt sources.
    *
    *
    ***************************************************************************/
    CY_ISR(MyPrototype_INTR_LO_ISR)
    {
        MyPrototype_IntrHandler(MyPrototype_INTR_CAUSE_LO_REG);
    }
#endif /* (CY_PSOC4) */


/* [] END OF FILE */
