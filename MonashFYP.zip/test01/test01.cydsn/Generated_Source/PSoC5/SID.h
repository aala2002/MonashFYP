/*******************************************************************************
* File Name: SID.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SID_H) /* Pins SID_H */
#define CY_PINS_SID_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "SID_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 SID__PORT == 15 && ((SID__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    SID_Write(uint8 value);
void    SID_SetDriveMode(uint8 mode);
uint8   SID_ReadDataReg(void);
uint8   SID_Read(void);
void    SID_SetInterruptMode(uint16 position, uint16 mode);
uint8   SID_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the SID_SetDriveMode() function.
     *  @{
     */
        #define SID_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define SID_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define SID_DM_RES_UP          PIN_DM_RES_UP
        #define SID_DM_RES_DWN         PIN_DM_RES_DWN
        #define SID_DM_OD_LO           PIN_DM_OD_LO
        #define SID_DM_OD_HI           PIN_DM_OD_HI
        #define SID_DM_STRONG          PIN_DM_STRONG
        #define SID_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define SID_MASK               SID__MASK
#define SID_SHIFT              SID__SHIFT
#define SID_WIDTH              1u

/* Interrupt constants */
#if defined(SID__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in SID_SetInterruptMode() function.
     *  @{
     */
        #define SID_INTR_NONE      (uint16)(0x0000u)
        #define SID_INTR_RISING    (uint16)(0x0001u)
        #define SID_INTR_FALLING   (uint16)(0x0002u)
        #define SID_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define SID_INTR_MASK      (0x01u) 
#endif /* (SID__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define SID_PS                     (* (reg8 *) SID__PS)
/* Data Register */
#define SID_DR                     (* (reg8 *) SID__DR)
/* Port Number */
#define SID_PRT_NUM                (* (reg8 *) SID__PRT) 
/* Connect to Analog Globals */                                                  
#define SID_AG                     (* (reg8 *) SID__AG)                       
/* Analog MUX bux enable */
#define SID_AMUX                   (* (reg8 *) SID__AMUX) 
/* Bidirectional Enable */                                                        
#define SID_BIE                    (* (reg8 *) SID__BIE)
/* Bit-mask for Aliased Register Access */
#define SID_BIT_MASK               (* (reg8 *) SID__BIT_MASK)
/* Bypass Enable */
#define SID_BYP                    (* (reg8 *) SID__BYP)
/* Port wide control signals */                                                   
#define SID_CTL                    (* (reg8 *) SID__CTL)
/* Drive Modes */
#define SID_DM0                    (* (reg8 *) SID__DM0) 
#define SID_DM1                    (* (reg8 *) SID__DM1)
#define SID_DM2                    (* (reg8 *) SID__DM2) 
/* Input Buffer Disable Override */
#define SID_INP_DIS                (* (reg8 *) SID__INP_DIS)
/* LCD Common or Segment Drive */
#define SID_LCD_COM_SEG            (* (reg8 *) SID__LCD_COM_SEG)
/* Enable Segment LCD */
#define SID_LCD_EN                 (* (reg8 *) SID__LCD_EN)
/* Slew Rate Control */
#define SID_SLW                    (* (reg8 *) SID__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define SID_PRTDSI__CAPS_SEL       (* (reg8 *) SID__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define SID_PRTDSI__DBL_SYNC_IN    (* (reg8 *) SID__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define SID_PRTDSI__OE_SEL0        (* (reg8 *) SID__PRTDSI__OE_SEL0) 
#define SID_PRTDSI__OE_SEL1        (* (reg8 *) SID__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define SID_PRTDSI__OUT_SEL0       (* (reg8 *) SID__PRTDSI__OUT_SEL0) 
#define SID_PRTDSI__OUT_SEL1       (* (reg8 *) SID__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define SID_PRTDSI__SYNC_OUT       (* (reg8 *) SID__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(SID__SIO_CFG)
    #define SID_SIO_HYST_EN        (* (reg8 *) SID__SIO_HYST_EN)
    #define SID_SIO_REG_HIFREQ     (* (reg8 *) SID__SIO_REG_HIFREQ)
    #define SID_SIO_CFG            (* (reg8 *) SID__SIO_CFG)
    #define SID_SIO_DIFF           (* (reg8 *) SID__SIO_DIFF)
#endif /* (SID__SIO_CFG) */

/* Interrupt Registers */
#if defined(SID__INTSTAT)
    #define SID_INTSTAT            (* (reg8 *) SID__INTSTAT)
    #define SID_SNAP               (* (reg8 *) SID__SNAP)
    
	#define SID_0_INTTYPE_REG 		(* (reg8 *) SID__0__INTTYPE)
#endif /* (SID__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_SID_H */


/* [] END OF FILE */
