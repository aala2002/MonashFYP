/***************************************************************************//**
* \file .h
* \version 3.20
*
* \brief
*  This file provides private function prototypes and constants for the 
*  USBFS component. It is not intended to be used in the user project.
*
********************************************************************************
* \copyright
* Copyright 2013-2016, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_USBFS_MyPrototype_pvt_H)
#define CY_USBFS_MyPrototype_pvt_H

#include "MyPrototype.h"
   
#ifdef MyPrototype_ENABLE_AUDIO_CLASS
    #include "MyPrototype_audio.h"
#endif /* MyPrototype_ENABLE_AUDIO_CLASS */

#ifdef MyPrototype_ENABLE_CDC_CLASS
    #include "MyPrototype_cdc.h"
#endif /* MyPrototype_ENABLE_CDC_CLASS */

#if (MyPrototype_ENABLE_MIDI_CLASS)
    #include "MyPrototype_midi.h"
#endif /* (MyPrototype_ENABLE_MIDI_CLASS) */

#if (MyPrototype_ENABLE_MSC_CLASS)
    #include "MyPrototype_msc.h"
#endif /* (MyPrototype_ENABLE_MSC_CLASS) */

#if (MyPrototype_EP_MANAGEMENT_DMA)
    #if (CY_PSOC4)
        #include <CyDMA.h>
    #else
        #include <CyDmac.h>
        #if ((MyPrototype_EP_MANAGEMENT_DMA_AUTO) && (MyPrototype_EP_DMA_AUTO_OPT == 0u))
            #include "MyPrototype_EP_DMA_Done_isr.h"
            #include "MyPrototype_EP8_DMA_Done_SR.h"
            #include "MyPrototype_EP17_DMA_Done_SR.h"
        #endif /* ((MyPrototype_EP_MANAGEMENT_DMA_AUTO) && (MyPrototype_EP_DMA_AUTO_OPT == 0u)) */
    #endif /* (CY_PSOC4) */
#endif /* (MyPrototype_EP_MANAGEMENT_DMA) */

#if (MyPrototype_DMA1_ACTIVE)
    #include "MyPrototype_ep1_dma.h"
    #define MyPrototype_EP1_DMA_CH     (MyPrototype_ep1_dma_CHANNEL)
#endif /* (MyPrototype_DMA1_ACTIVE) */

#if (MyPrototype_DMA2_ACTIVE)
    #include "MyPrototype_ep2_dma.h"
    #define MyPrototype_EP2_DMA_CH     (MyPrototype_ep2_dma_CHANNEL)
#endif /* (MyPrototype_DMA2_ACTIVE) */

#if (MyPrototype_DMA3_ACTIVE)
    #include "MyPrototype_ep3_dma.h"
    #define MyPrototype_EP3_DMA_CH     (MyPrototype_ep3_dma_CHANNEL)
#endif /* (MyPrototype_DMA3_ACTIVE) */

#if (MyPrototype_DMA4_ACTIVE)
    #include "MyPrototype_ep4_dma.h"
    #define MyPrototype_EP4_DMA_CH     (MyPrototype_ep4_dma_CHANNEL)
#endif /* (MyPrototype_DMA4_ACTIVE) */

#if (MyPrototype_DMA5_ACTIVE)
    #include "MyPrototype_ep5_dma.h"
    #define MyPrototype_EP5_DMA_CH     (MyPrototype_ep5_dma_CHANNEL)
#endif /* (MyPrototype_DMA5_ACTIVE) */

#if (MyPrototype_DMA6_ACTIVE)
    #include "MyPrototype_ep6_dma.h"
    #define MyPrototype_EP6_DMA_CH     (MyPrototype_ep6_dma_CHANNEL)
#endif /* (MyPrototype_DMA6_ACTIVE) */

#if (MyPrototype_DMA7_ACTIVE)
    #include "MyPrototype_ep7_dma.h"
    #define MyPrototype_EP7_DMA_CH     (MyPrototype_ep7_dma_CHANNEL)
#endif /* (MyPrototype_DMA7_ACTIVE) */

#if (MyPrototype_DMA8_ACTIVE)
    #include "MyPrototype_ep8_dma.h"
    #define MyPrototype_EP8_DMA_CH     (MyPrototype_ep8_dma_CHANNEL)
#endif /* (MyPrototype_DMA8_ACTIVE) */


/***************************************
*     Private Variables
***************************************/

/* Generated external references for descriptors. */
extern const uint8 CYCODE MyPrototype_DEVICE0_DESCR[18u];
extern const uint8 CYCODE MyPrototype_DEVICE0_CONFIGURATION0_DESCR[67u];
extern const T_MyPrototype_EP_SETTINGS_BLOCK CYCODE MyPrototype_DEVICE0_CONFIGURATION0_EP_SETTINGS_TABLE[3u];
extern const uint8 CYCODE MyPrototype_DEVICE0_CONFIGURATION0_INTERFACE_CLASS[2u];
extern const T_MyPrototype_LUT CYCODE MyPrototype_DEVICE0_CONFIGURATION0_TABLE[5u];
extern const T_MyPrototype_LUT CYCODE MyPrototype_DEVICE0_TABLE[3u];
extern const T_MyPrototype_LUT CYCODE MyPrototype_TABLE[1u];
extern const uint8 CYCODE MyPrototype_SN_STRING_DESCRIPTOR[2];
extern const uint8 CYCODE MyPrototype_STRING_DESCRIPTORS[159u];


extern const uint8 CYCODE MyPrototype_MSOS_DESCRIPTOR[MyPrototype_MSOS_DESCRIPTOR_LENGTH];
extern const uint8 CYCODE MyPrototype_MSOS_CONFIGURATION_DESCR[MyPrototype_MSOS_CONF_DESCR_LENGTH];
#if defined(MyPrototype_ENABLE_IDSN_STRING)
    extern uint8 MyPrototype_idSerialNumberStringDescriptor[MyPrototype_IDSN_DESCR_LENGTH];
#endif /* (MyPrototype_ENABLE_IDSN_STRING) */

extern volatile uint8 MyPrototype_interfaceNumber;
extern volatile uint8 MyPrototype_interfaceSetting[MyPrototype_MAX_INTERFACES_NUMBER];
extern volatile uint8 MyPrototype_interfaceSettingLast[MyPrototype_MAX_INTERFACES_NUMBER];
extern volatile uint8 MyPrototype_deviceAddress;
extern volatile uint8 MyPrototype_interfaceStatus[MyPrototype_MAX_INTERFACES_NUMBER];
extern const uint8 CYCODE *MyPrototype_interfaceClass;

extern volatile T_MyPrototype_EP_CTL_BLOCK MyPrototype_EP[MyPrototype_MAX_EP];
extern volatile T_MyPrototype_TD MyPrototype_currentTD;

#if (MyPrototype_EP_MANAGEMENT_DMA)
    #if (CY_PSOC4)
        extern const uint8 MyPrototype_DmaChan[MyPrototype_MAX_EP];
    #else
        extern uint8 MyPrototype_DmaChan[MyPrototype_MAX_EP];
        extern uint8 MyPrototype_DmaTd  [MyPrototype_MAX_EP];
    #endif /* (CY_PSOC4) */
#endif /* (MyPrototype_EP_MANAGEMENT_DMA) */

#if (MyPrototype_EP_MANAGEMENT_DMA_AUTO)
#if (CY_PSOC4)
    extern uint8  MyPrototype_DmaEpBurstCnt   [MyPrototype_MAX_EP];
    extern uint8  MyPrototype_DmaEpLastBurstEl[MyPrototype_MAX_EP];

    extern uint8  MyPrototype_DmaEpBurstCntBackup  [MyPrototype_MAX_EP];
    extern uint32 MyPrototype_DmaEpBufferAddrBackup[MyPrototype_MAX_EP];
    
    extern const uint8 MyPrototype_DmaReqOut     [MyPrototype_MAX_EP];    
    extern const uint8 MyPrototype_DmaBurstEndOut[MyPrototype_MAX_EP];
#else
    #if (MyPrototype_EP_DMA_AUTO_OPT == 0u)
        extern uint8 MyPrototype_DmaNextTd[MyPrototype_MAX_EP];
        extern volatile uint16 MyPrototype_inLength [MyPrototype_MAX_EP];
        extern volatile uint8  MyPrototype_inBufFull[MyPrototype_MAX_EP];
        extern const uint8 MyPrototype_epX_TD_TERMOUT_EN[MyPrototype_MAX_EP];
        extern const uint8 *MyPrototype_inDataPointer[MyPrototype_MAX_EP];
    #endif /* (MyPrototype_EP_DMA_AUTO_OPT == 0u) */
#endif /* CY_PSOC4 */
#endif /* (MyPrototype_EP_MANAGEMENT_DMA_AUTO) */

extern volatile uint8 MyPrototype_ep0Toggle;
extern volatile uint8 MyPrototype_lastPacketSize;
extern volatile uint8 MyPrototype_ep0Mode;
extern volatile uint8 MyPrototype_ep0Count;
extern volatile uint16 MyPrototype_transferByteCount;


/***************************************
*     Private Function Prototypes
***************************************/
void  MyPrototype_ReInitComponent(void)            ;
void  MyPrototype_HandleSetup(void)                ;
void  MyPrototype_HandleIN(void)                   ;
void  MyPrototype_HandleOUT(void)                  ;
void  MyPrototype_LoadEP0(void)                    ;
uint8 MyPrototype_InitControlRead(void)            ;
uint8 MyPrototype_InitControlWrite(void)           ;
void  MyPrototype_ControlReadDataStage(void)       ;
void  MyPrototype_ControlReadStatusStage(void)     ;
void  MyPrototype_ControlReadPrematureStatus(void) ;
uint8 MyPrototype_InitControlWrite(void)           ;
uint8 MyPrototype_InitZeroLengthControlTransfer(void) ;
void  MyPrototype_ControlWriteDataStage(void)      ;
void  MyPrototype_ControlWriteStatusStage(void)    ;
void  MyPrototype_ControlWritePrematureStatus(void);
uint8 MyPrototype_InitNoDataControlTransfer(void)  ;
void  MyPrototype_NoDataControlStatusStage(void)   ;
void  MyPrototype_InitializeStatusBlock(void)      ;
void  MyPrototype_UpdateStatusBlock(uint8 completionCode) ;
uint8 MyPrototype_DispatchClassRqst(void)          ;

void MyPrototype_Config(uint8 clearAltSetting) ;
void MyPrototype_ConfigAltChanged(void)        ;
void MyPrototype_ConfigReg(void)               ;
void MyPrototype_EpStateInit(void)             ;


const T_MyPrototype_LUT CYCODE *MyPrototype_GetConfigTablePtr(uint8 confIndex);
const T_MyPrototype_LUT CYCODE *MyPrototype_GetDeviceTablePtr(void)           ;
#if (MyPrototype_BOS_ENABLE)
    const T_MyPrototype_LUT CYCODE *MyPrototype_GetBOSPtr(void)               ;
#endif /* (MyPrototype_BOS_ENABLE) */
const uint8 CYCODE *MyPrototype_GetInterfaceClassTablePtr(void)                    ;
uint8 MyPrototype_ClearEndpointHalt(void)                                          ;
uint8 MyPrototype_SetEndpointHalt(void)                                            ;
uint8 MyPrototype_ValidateAlternateSetting(void)                                   ;

void MyPrototype_SaveConfig(void)      ;
void MyPrototype_RestoreConfig(void)   ;

#if (CY_PSOC3 || CY_PSOC5LP)
    #if (MyPrototype_EP_MANAGEMENT_DMA_AUTO && (MyPrototype_EP_DMA_AUTO_OPT == 0u))
        void MyPrototype_LoadNextInEP(uint8 epNumber, uint8 mode)  ;
    #endif /* (MyPrototype_EP_MANAGEMENT_DMA_AUTO && (MyPrototype_EP_DMA_AUTO_OPT == 0u)) */
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

#if defined(MyPrototype_ENABLE_IDSN_STRING)
    void MyPrototype_ReadDieID(uint8 descr[])  ;
#endif /* MyPrototype_ENABLE_IDSN_STRING */

#if defined(MyPrototype_ENABLE_HID_CLASS)
    uint8 MyPrototype_DispatchHIDClassRqst(void) ;
#endif /* (MyPrototype_ENABLE_HID_CLASS) */

#if defined(MyPrototype_ENABLE_AUDIO_CLASS)
    uint8 MyPrototype_DispatchAUDIOClassRqst(void) ;
#endif /* (MyPrototype_ENABLE_AUDIO_CLASS) */

#if defined(MyPrototype_ENABLE_CDC_CLASS)
    uint8 MyPrototype_DispatchCDCClassRqst(void) ;
#endif /* (MyPrototype_ENABLE_CDC_CLASS) */

#if (MyPrototype_ENABLE_MSC_CLASS)
    #if (MyPrototype_HANDLE_MSC_REQUESTS)
        uint8 MyPrototype_DispatchMSCClassRqst(void) ;
    #endif /* (MyPrototype_HANDLE_MSC_REQUESTS) */
#endif /* (MyPrototype_ENABLE_MSC_CLASS */

CY_ISR_PROTO(MyPrototype_EP_0_ISR);
CY_ISR_PROTO(MyPrototype_BUS_RESET_ISR);

#if (MyPrototype_SOF_ISR_ACTIVE)
    CY_ISR_PROTO(MyPrototype_SOF_ISR);
#endif /* (MyPrototype_SOF_ISR_ACTIVE) */

#if (MyPrototype_EP1_ISR_ACTIVE)
    CY_ISR_PROTO(MyPrototype_EP_1_ISR);
#endif /* (MyPrototype_EP1_ISR_ACTIVE) */

#if (MyPrototype_EP2_ISR_ACTIVE)
    CY_ISR_PROTO(MyPrototype_EP_2_ISR);
#endif /* (MyPrototype_EP2_ISR_ACTIVE) */

#if (MyPrototype_EP3_ISR_ACTIVE)
    CY_ISR_PROTO(MyPrototype_EP_3_ISR);
#endif /* (MyPrototype_EP3_ISR_ACTIVE) */

#if (MyPrototype_EP4_ISR_ACTIVE)
    CY_ISR_PROTO(MyPrototype_EP_4_ISR);
#endif /* (MyPrototype_EP4_ISR_ACTIVE) */

#if (MyPrototype_EP5_ISR_ACTIVE)
    CY_ISR_PROTO(MyPrototype_EP_5_ISR);
#endif /* (MyPrototype_EP5_ISR_ACTIVE) */

#if (MyPrototype_EP6_ISR_ACTIVE)
    CY_ISR_PROTO(MyPrototype_EP_6_ISR);
#endif /* (MyPrototype_EP6_ISR_ACTIVE) */

#if (MyPrototype_EP7_ISR_ACTIVE)
    CY_ISR_PROTO(MyPrototype_EP_7_ISR);
#endif /* (MyPrototype_EP7_ISR_ACTIVE) */

#if (MyPrototype_EP8_ISR_ACTIVE)
    CY_ISR_PROTO(MyPrototype_EP_8_ISR);
#endif /* (MyPrototype_EP8_ISR_ACTIVE) */

#if (MyPrototype_EP_MANAGEMENT_DMA)
    CY_ISR_PROTO(MyPrototype_ARB_ISR);
#endif /* (MyPrototype_EP_MANAGEMENT_DMA) */

#if (MyPrototype_DP_ISR_ACTIVE)
    CY_ISR_PROTO(MyPrototype_DP_ISR);
#endif /* (MyPrototype_DP_ISR_ACTIVE) */

#if (CY_PSOC4)
    CY_ISR_PROTO(MyPrototype_INTR_HI_ISR);
    CY_ISR_PROTO(MyPrototype_INTR_MED_ISR);
    CY_ISR_PROTO(MyPrototype_INTR_LO_ISR);
    #if (MyPrototype_LPM_ACTIVE)
        CY_ISR_PROTO(MyPrototype_LPM_ISR);
    #endif /* (MyPrototype_LPM_ACTIVE) */
#endif /* (CY_PSOC4) */

#if (MyPrototype_EP_MANAGEMENT_DMA_AUTO)
#if (CY_PSOC4)
    #if (MyPrototype_DMA1_ACTIVE)
        void MyPrototype_EP1_DMA_DONE_ISR(void);
    #endif /* (MyPrototype_DMA1_ACTIVE) */

    #if (MyPrototype_DMA2_ACTIVE)
        void MyPrototype_EP2_DMA_DONE_ISR(void);
    #endif /* (MyPrototype_DMA2_ACTIVE) */

    #if (MyPrototype_DMA3_ACTIVE)
        void MyPrototype_EP3_DMA_DONE_ISR(void);
    #endif /* (MyPrototype_DMA3_ACTIVE) */

    #if (MyPrototype_DMA4_ACTIVE)
        void MyPrototype_EP4_DMA_DONE_ISR(void);
    #endif /* (MyPrototype_DMA4_ACTIVE) */

    #if (MyPrototype_DMA5_ACTIVE)
        void MyPrototype_EP5_DMA_DONE_ISR(void);
    #endif /* (MyPrototype_DMA5_ACTIVE) */

    #if (MyPrototype_DMA6_ACTIVE)
        void MyPrototype_EP6_DMA_DONE_ISR(void);
    #endif /* (MyPrototype_DMA6_ACTIVE) */

    #if (MyPrototype_DMA7_ACTIVE)
        void MyPrototype_EP7_DMA_DONE_ISR(void);
    #endif /* (MyPrototype_DMA7_ACTIVE) */

    #if (MyPrototype_DMA8_ACTIVE)
        void MyPrototype_EP8_DMA_DONE_ISR(void);
    #endif /* (MyPrototype_DMA8_ACTIVE) */

#else
    #if (MyPrototype_EP_DMA_AUTO_OPT == 0u)
        CY_ISR_PROTO(MyPrototype_EP_DMA_DONE_ISR);
    #endif /* (MyPrototype_EP_DMA_AUTO_OPT == 0u) */
#endif /* (CY_PSOC4) */
#endif /* (MyPrototype_EP_MANAGEMENT_DMA_AUTO) */


/***************************************
*         Request Handlers
***************************************/

uint8 MyPrototype_HandleStandardRqst(void) ;
uint8 MyPrototype_DispatchClassRqst(void)  ;
uint8 MyPrototype_HandleVendorRqst(void)   ;


/***************************************
*    HID Internal references
***************************************/

#if defined(MyPrototype_ENABLE_HID_CLASS)
    void MyPrototype_FindReport(void)            ;
    void MyPrototype_FindReportDescriptor(void)  ;
    void MyPrototype_FindHidClassDecriptor(void) ;
#endif /* MyPrototype_ENABLE_HID_CLASS */


/***************************************
*    MIDI Internal references
***************************************/

#if defined(MyPrototype_ENABLE_MIDI_STREAMING)
    void MyPrototype_MIDI_IN_EP_Service(void)  ;
#endif /* (MyPrototype_ENABLE_MIDI_STREAMING) */


/***************************************
*    CDC Internal references
***************************************/

#if defined(MyPrototype_ENABLE_CDC_CLASS)

    typedef struct
    {
        uint8  bRequestType;
        uint8  bNotification;
        uint8  wValue;
        uint8  wValueMSB;
        uint8  wIndex;
        uint8  wIndexMSB;
        uint8  wLength;
        uint8  wLengthMSB;
        uint8  wSerialState;
        uint8  wSerialStateMSB;
    } t_MyPrototype_cdc_notification;

    uint8 MyPrototype_GetInterfaceComPort(uint8 interface) ;
    uint8 MyPrototype_Cdc_EpInit( const T_MyPrototype_EP_SETTINGS_BLOCK CYCODE *pEP, uint8 epNum, uint8 cdcComNums) ;

    extern volatile uint8  MyPrototype_cdc_dataInEpList[MyPrototype_MAX_MULTI_COM_NUM];
    extern volatile uint8  MyPrototype_cdc_dataOutEpList[MyPrototype_MAX_MULTI_COM_NUM];
    extern volatile uint8  MyPrototype_cdc_commInEpList[MyPrototype_MAX_MULTI_COM_NUM];
#endif /* (MyPrototype_ENABLE_CDC_CLASS) */


#endif /* CY_USBFS_MyPrototype_pvt_H */


/* [] END OF FILE */
