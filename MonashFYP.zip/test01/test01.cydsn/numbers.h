/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#ifndef NUMBERS_H
#define NUMBERS_H

#include <stdint.h>

extern const uint8_t number0[];
extern const uint8_t number1[];
extern const uint8_t number2[];
extern const uint8_t number3[];
extern const uint8_t number4[];
extern const uint8_t number5[];
extern const uint8_t number6[];
extern const uint8_t number7[];
extern const uint8_t number8[];
extern const uint8_t number9[];

const uint8_t catBitmap[32];

const uint8_t* getNumberArray(int digit);
void displayNumber(int number, uint8_t startX, uint8_t startY);

#endif

