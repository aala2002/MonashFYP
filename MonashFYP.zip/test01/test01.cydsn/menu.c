/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// menu.c
#include "menu.h"
#include "display.h" // Assume this is where displayText and displayTextInversed are declared
#include <stddef.h>  // For NULL
#include "obd.h"
#include "letters.h"
#include "project.h"
#include "stdio.h"

// Global variables
static MenuPage* currentMenuPage = NULL;
static MenuPage* parentMenuPage = NULL; // For tracking the parent menu, if needed
static uint8_t contrastValue = 225; // Default value




void displayRPM() {
    keepRunningCurrentAction = 1;
    displayOBDDataForPID(OBDII_PID_ENGINE_RPM);
}
void displaySpeed() {
    keepRunningCurrentAction = 1;
    displayOBDDataForPID(OBDII_PID_VEHICLE_SPEED);
}
void displayTemp() {
    keepRunningCurrentAction = 1;
    displayOBDDataForPID(OBDII_PID_COOLANT_TEMP);
}
void displayPos() {
    keepRunningCurrentAction = 1;
    displayOBDDataForPID(OBDII_PID_THROTTLE_POS);
}

void displayCurrentDTC() {
    keepRunningCurrentAction = 1;
    processDTCResponse(OBDII_MODE_GET_DTC);
}

void deleteAllCodes() {
    keepRunningCurrentAction = 1;
    handleDeleteCodes();
}

void displayPendingDTC() {
    keepRunningCurrentAction = 1;
    processDTCResponse(OBDII_MODE_GET_PENDING_DTC);
}

void freezeFrameMenu() {
    keepRunningCurrentAction = 1;
    processFreezeFrameData();
}



void contrastUp() {
    if (contrastValue > 234) {
        contrastValue = 255;
        VDAC8_1_SetValue(contrastValue);}
    else {
        contrastValue += 20;
        VDAC8_1_SetValue(contrastValue);}
}

void contrastDown() {
    if (contrastValue < 21) {
        contrastValue = 0;
        VDAC8_1_SetValue(contrastValue);}
    else {
        contrastValue -= 20;
        VDAC8_1_SetValue(contrastValue);}
}

void setRawData() {
    currentDataType = RAW_DATA;
}

void setInterpretedData() {
    currentDataType = INTERPRETED_DATA;
}


static MenuItem pidMenuItems[] = {
    {"* Rpm", displayRPM, NULL},
    {"* Speed", displaySpeed, NULL},
    {"* Temp", displayTemp, NULL},
    {"* Position", displayPos, NULL},
};

static MenuPage pidMenuPage = {"LIVE DATA",pidMenuItems, sizeof(pidMenuItems) / sizeof(MenuItem), 0, NULL};

static MenuItem readCodeItems[] = {
    {"* Stored", displayCurrentDTC, NULL},
    {"* Pending", displayPendingDTC, NULL}
};

static MenuPage readCodePage = {" DTC OPTS",readCodeItems, sizeof(readCodeItems) / sizeof(MenuItem), 0, NULL};

static MenuItem contrast[] = {
    {"* Contrast Up",contrastUp,NULL},
    {"* Contrast Down",contrastDown,NULL},
};

static MenuPage contrastPage = {"   CONTRAST",contrast,sizeof(contrast) / sizeof(MenuItem), 0, NULL};

static MenuItem dataType[] = {
    {"* Raw", setRawData, NULL},
    {"* Interpreted", setInterpretedData, NULL},
};

static MenuPage dataTypePage = {"   DATA TYPE",dataType,sizeof(dataType) / sizeof(MenuItem), 0, NULL};

static MenuItem setting[] = {
    {"* Contrast",NULL,&contrastPage},
    {"* Data Type",NULL,&dataTypePage},
};

static MenuPage settingPage = {"   SETTINGS",setting,sizeof(setting) / sizeof(MenuItem), 0, NULL};

static MenuItem deleteCodes[] = {
    {"* Yes",deleteAllCodes,NULL},
    {"* No",NULL,NULL}
};

static MenuPage deleteCodesPage = {"ARE YOU SURE",deleteCodes,sizeof(deleteCodes) / sizeof(MenuItem), 0, NULL};

static MenuItem diagnostics[] = {
    {"*Read Codes", NULL, &readCodePage},
    {"*Freeze Frame", freezeFrameMenu, NULL},
    {"*OnBoard Tests", NULL, &settingPage},
    {"*Clear Codes", NULL, &deleteCodesPage}
};

static MenuPage diagnosticsPage = {"  Diagnostics",diagnostics, sizeof(diagnostics) / sizeof(MenuItem), 0, NULL};


static MenuItem memory[] = {
    //{"* Stored DTC", displayStoredDTCs, NULL},
    //{"* Pending DTC", displayPendingDTCs, NULL},
    //{"* Freeze Frame", displayPendingDTCs, NULL},
    //{"* Information", displayPendingDTCs, NULL}
};

static MenuPage memoryPage = {"  MEMORY",memory, sizeof(memory) / sizeof(MenuItem), 0, NULL};

// Main menu initialization
static MenuItem mainMenuItems[] = {
    {"Live Data", NULL, &pidMenuPage},
    {"Diagnostics", NULL, &diagnosticsPage},
    {"Information",NULL, &memoryPage},
    {"Storage",NULL, &memoryPage},
    {"Settings", NULL, &settingPage}    
};

static MenuPage mainMenuPage = {"  SERVICE MENU",mainMenuItems, sizeof(mainMenuItems) / sizeof(MenuItem), 0, NULL};

void initializeMainMenu(void) {
    currentMenuPage = &mainMenuPage; // Starting with the main menu
    pidMenuPage.parentMenu = &mainMenuPage; // Setting parent menu for the PID menu
    settingPage.parentMenu = &mainMenuPage; // Setting parent menu for the PID menu
    contrastPage.parentMenu = &mainMenuPage; // Setting parent menu for the PID menu
    readCodePage.parentMenu = &mainMenuPage; // Setting parent menu for the PID menu
    diagnosticsPage.parentMenu = &mainMenuPage;
    
    displayMenuWithHighlight(currentMenuPage->selectedItem);
}

void navigateUp(void) {
    if (currentMenuPage->selectedItem > 0) {
        currentMenuPage->selectedItem--;
    }
    displayMenuWithHighlight(currentMenuPage->selectedItem);
}

void navigateDown(void) {
    // Navigate down in the current menu
    if (currentMenuPage->selectedItem < currentMenuPage->numberOfItems - 1) {
        currentMenuPage->selectedItem++;
    }
    displayMenuWithHighlight(currentMenuPage->selectedItem);
}

void selectMenuItem(void) {
    // Select the current menu item
    turnOffAllPixels();
    MenuItem selectedItem = currentMenuPage->items[currentMenuPage->selectedItem];
    if (selectedItem.action != NULL) {
        selectedItem.action(); // Perform the action
    } else if (selectedItem.submenu != NULL) {
        parentMenuPage = currentMenuPage; // Set the parent menu
        currentMenuPage = selectedItem.submenu; // Go to the submenu
        currentMenuPage->selectedItem = 0; // Reset submenu selection
    }
    displayMenuWithHighlight(currentMenuPage->selectedItem);
}

void goBack(void) {
    turnOffAllPixels();
    // Check if there is a parent menu to return to
    if (parentMenuPage != NULL) {
        // Go back to the parent menu
        currentMenuPage = parentMenuPage;
        parentMenuPage = currentMenuPage->parentMenu; // Update the parent menu to the grandparent menu, if any
        displayMenuWithHighlight(currentMenuPage->selectedItem);
    } else {
        // Optional: Define behavior if there's no parent menu to return to
        // For example, you could reset to the main menu or simply do nothing
    }
}

void setParentMenu(MenuPage* parent) {
    parentMenuPage = parent;
}

void setCurrentMenu(MenuPage* menu) {
    currentMenuPage = menu;
}

// Implement other menu-related functions here...
void displayTwoCharsDirectly(const uint8_t* bitmap1, const uint8_t* bitmap2, uint8_t startX, uint8_t startY) {
    for (int row = 0; row < 8; ++row) {
        uint8_t byte1 = 0;
        uint8_t byte2 = 0;

        // Construct bytes for two characters
        if (bitmap1) {
            for (int bit = 0; bit < 8; ++bit) {
                if (bitmap1[row] & (0x80 >> bit)) {
                    byte1 |= (0x80 >> bit);
                }
            }
        }
        if (bitmap2) {
            for (int bit = 0; bit < 8; ++bit) {
                if (bitmap2[row] & (0x80 >> bit)) {
                    byte2 |= (0x80 >> bit);
                }
            }
        }

        // Call setWord with the constructed bytes
        setWord(startX, startY + row, byte1, byte2);
    }
}

void displayTwoCharsDirectlyInversed(const uint8_t* bitmap1, const uint8_t* bitmap2, uint8_t startX, uint8_t startY) {
    for (int row = 0; row < 8; ++row) {
        uint8_t byte1 = 0xFF; // Start with all bits set for inversion
        uint8_t byte2 = 0xFF; // Start with all bits set for inversion

        // Construct bytes for two characters
        if (bitmap1) {
            for (int bit = 0; bit < 8; ++bit) {
                if (bitmap1[row] & (0x80 >> bit)) {
                    byte1 &= ~(0x80 >> bit); // Inverse the bit
                }
            }
        }
        if (bitmap2) {
            for (int bit = 0; bit < 8; ++bit) {
                if (bitmap2[row] & (0x80 >> bit)) {
                    byte2 &= ~(0x80 >> bit); // Inverse the bit
                }
            }
        }

        // Call setWord with the constructed bytes
        setWord(startX, startY + row, byte1, byte2);
    }
}


void displayText(const char* str, uint8_t startX, uint8_t startY) {
    while (*str) {
        const uint8_t* charBitmap1 = getCharBitmap(*str);
        const uint8_t* charBitmap2 = NULL;
        if (*(str + 1)) {
            charBitmap2 = getCharBitmap(*(str + 1));
        }

        if (charBitmap1) {
            displayTwoCharsDirectly(charBitmap1, charBitmap2, startX, startY);
            startX += 16; // Move to the next pair of character positions
        }

        if (!charBitmap2) {
            break; // If there's no second character, we're done
        }

        str += 2; // Move to the next pair of characters
    }
}
void displayTextInversed(const char* str, uint8_t startX, uint8_t startY) {
    while (*str) {
        const uint8_t* charBitmap1 = getCharBitmap(*str);
        const uint8_t* charBitmap2 = NULL;
        if (*(str + 1)) {
            charBitmap2 = getCharBitmap(*(str + 1));
        }

        if (charBitmap1) {
            displayTwoCharsDirectlyInversed(charBitmap1, charBitmap2, startX, startY);
            startX += 16; // Move to the next pair of character positions
        }

        if (!charBitmap2) {
            break; // If there's no second character, we're done
        }

        str += 2; // Move to the next pair of characters
    }
}

void displayMenuWithHighlight(int highlightedItem) {
    
    displayText(currentMenuPage->title,0,0);
    displayLine(8);
    
    
    for (int i = 0; i < currentMenuPage->numberOfItems; ++i) {
        char displayBuffer[50];  // Buffer for formatted menu item text
        if (i == highlightedItem) {
            sprintf(displayBuffer, ">%s", currentMenuPage->items[i].name);  // Add '>' before highlighted item
            displayTextInversed(displayBuffer, 0, 11 + i * MENU_ITEM_HEIGHT);
        } else {
            sprintf(displayBuffer, " %s", currentMenuPage->items[i].name);  // Maintain alignment for non-highlighted items
            displayText(displayBuffer, 0, 11 + i * MENU_ITEM_HEIGHT);
        }
    }
}

#define MAX_DISPLAY_MESSAGES 3  // Maximum messages that can be shown at once, excluding the header
void sendStringViaUART(const char* str) {
    while (*str != '\0') {
        UART_1_PutChar(*str++);  // Transmit each character
    }
    UART_1_PutChar('\n'); // New line for better readability in terminal
}

#define MAX_MESSAGES 3
#define MESSAGE_LENGTH 25  // Including null terminator

static char messageBuffer[MAX_MESSAGES][MESSAGE_LENGTH];
static int messageCount = 0;

void displayMessages() {
    int startRow = 16;  // Starting row for displaying messages
    displayText("  CAN MESSAGES", 0, 0); // Header at the top
    
    for (int i = 0; i < messageCount; i++) {
        char line1[14], line2[14];
        line1[0] = '>'; // Start with *
        strncpy(line1 + 1, messageBuffer[i], 11); // Copy the first 11 characters after *
        line1[12] = '\0';  // Ensure null termination
        strncpy(line2, messageBuffer[i] + 11, 12); // Copy the next 11 characters
        line2[13] = '\0';  // Ensure null termination

        displayText(line1, 0, startRow); // Display the first part
        displayText(line2, 0, startRow + 8); // Display the second part
        startRow += 16; // Move to the next message position
    }
}

void updateDisplayWithNewMessage(char* newMessage) {
    // Shift the old messages up if the buffer is full
    if (messageCount == MAX_MESSAGES) {
        for (int i = 1; i < MAX_MESSAGES; i++) {
            strcpy(messageBuffer[i - 1], messageBuffer[i]);
        }
        messageCount--;
    }

    // Add the new message at the end of the buffer
    strncpy(messageBuffer[messageCount], newMessage, MESSAGE_LENGTH - 1);
    messageBuffer[messageCount][MESSAGE_LENGTH - 1] = '\0'; // Ensure null termination
    messageCount++;

    displayMessages();  // Refresh the display with new message set
}


/* [] END OF FILE */