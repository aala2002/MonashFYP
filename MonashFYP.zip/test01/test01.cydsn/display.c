/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#include "display.h"
#include "project.h"
#include "numbers.h"
#include <time.h>
#include "stdio.h"

uint8_t currentData = 1; // 1 means data1, 2 means data2
uint8_t memoryByte = 0;

void sendCommand(uint8_t cmd) {
    LCD_Control_Write(0x0c); // RS=0 (Command mode), RW=0, RST=1, PSB=1, E=0
    CyDelayUs(10);
    Custom_LCD_Data_Write(cmd); // Setup command
    LCD_Control_Write(0x1c); // RS=0, RW=0, RST=1, PSB=1, E=1
    CyDelayUs(10);
    LCD_Control_Write(0x0c); // E=0 (after pulsing it high), RS=0, RW=0, RST=1, PSB=1
    CyDelay(2); 
}

void sendData(uint8_t data) {
    LCD_Control_Write(0x0f); // RS=1 , RW=1, RST=1, PSB=1, E=0 
    CyDelayUs(10);  
    LCD_Control_Write(0x0d); // RS=1 , RW=0, RST=1, PSB=1, E=0 
    CyDelayUs(10);  
    LCD_Control_Write(0x1d); // RS=1 , RW=0, RST=1, PSB=1, E=1 
    CyDelayUs(10);  
    Custom_LCD_Data_Write(data); // Setup data
    CyDelayUs(10);
    LCD_Control_Write(0x0d); // RS=1 , RW=0, RST=1, PSB=1, E=0
    CyDelayUs(10);
    LCD_Control_Write(0x0f); // RS=1 , RW=1, RST=1, PSB=1, E=0
}

void setGDRAMAddress(uint8_t x, uint8_t y) {
 
    x = 127-x;
    y = 31 - y;
    
    
    sendCommand(0x80 | y);  // Set vertical address (Y first, as per most datasheets)
    CyDelayUs(72);
    sendCommand(0x80 | x);  // Set horizontal address
    CyDelayUs(72);
}


void Custom_LCD_Data_Write(uint8_t data) {
    D0_1_SetDriveMode(D0_1_DM_STRONG);
    D1_1_SetDriveMode(D0_1_DM_STRONG);
    D2_1_SetDriveMode(D0_1_DM_STRONG);
    D3_1_SetDriveMode(D0_1_DM_STRONG);
    D4_1_SetDriveMode(D0_1_DM_STRONG);
    D5_1_SetDriveMode(D0_1_DM_STRONG);
    D6_1_SetDriveMode(D0_1_DM_STRONG);
    D7_1_SetDriveMode(D0_1_DM_STRONG);
    
    D0_1_Write((data >> 0) & 0x01);
    D1_1_Write((data >> 1) & 0x01);
    D2_1_Write((data >> 2) & 0x01);
    D3_1_Write((data >> 3) & 0x01);
    D4_1_Write((data >> 4) & 0x01);
    D5_1_Write((data >> 5) & 0x01);
    D6_1_Write((data >> 6) & 0x01);
    D7_1_Write((data >> 7) & 0x01);
}
uint8_t Custom_LCD_Data_Read() {
    uint8_t data = 0;

    data |= D0_1_Read() << 0;
    data |= D1_1_Read() << 1;
    data |= D2_1_Read() << 2;
    data |= D3_1_Read() << 3;
    data |= D4_1_Read() << 4;
    data |= D5_1_Read() << 5;
    data |= D6_1_Read() << 6;
    data |= D7_1_Read() << 7;
    return data;
}

uint8_t readData(uint8_t skipDummy) {
    uint8_t data;
    D0_1_SetDriveMode(D0_1_DM_DIG_HIZ);
    D1_1_SetDriveMode(D0_1_DM_DIG_HIZ);
    D2_1_SetDriveMode(D0_1_DM_DIG_HIZ);
    D3_1_SetDriveMode(D0_1_DM_DIG_HIZ);
    D4_1_SetDriveMode(D0_1_DM_DIG_HIZ);
    D5_1_SetDriveMode(D0_1_DM_DIG_HIZ);
    D6_1_SetDriveMode(D0_1_DM_DIG_HIZ);
    D7_1_SetDriveMode(D0_1_DM_DIG_HIZ);
    // Setup for reading: RS=1, R/W=1
    LCD_Control_Write(0x0f); 
    CyDelayUs(10);
    if (!skipDummy) {
        // First E pulse: Dummy read
        LCD_Control_Write(0x1f); 
        CyDelayUs(10);
        LCD_Control_Write(0x0f);
        CyDelayUs(10);
    }
    // Second E pulse: Actual Data Read
    LCD_Control_Write(0x1f); 
    CyDelayUs(10);
    data = Custom_LCD_Data_Read();
    CyDelayUs(10);
    LCD_Control_Write(0x0f);
    CyDelayUs(10);
    return data;
}


void initializeLCD() {
    CyDelay(200); // Wait more than 40ms after Vdd rises to 4.5V

    LCD_Control_Write(0x00); // RST=0,PSB = 0
    CyDelayUs(5);
    LCD_Control_Write(0x0c); // RS = 0, RW = 0, RST=1, PSB = 1, E = 0

    sendCommand(0x30); // 8-bit mode, basic instruction set 00001100
    CyDelayUs(110);   // Wait time >100uS
    sendCommand(0x30); // 8-bit mode, basic instruction set again 00001100
    CyDelayUs(50);    // Wait time >37uS
    sendCommand(0x0F); // Turn on the display with cursor and blink
    CyDelay(110);   // Wait time >100uS
    sendCommand(0x01); // Clear display
    CyDelay(15);      // Wait time >10mS
    sendCommand(0x06); // Entry mode set: Increment cursor by 1, No shift
}

void initializeGraphicsMode() {
    sendCommand(0x34);  // Function Set (Basic instruction set)
    CyDelayUs(110);     // As per the datasheet

    sendCommand(0x34);  // Function Set (Extended instruction set)
    CyDelayUs(50);      // As per the datasheet

    sendCommand(0x36);  // Extended Function Set (Graphics ON)
    CyDelayUs(50);      // As per the datasheet
}

void turnOnAllPixels() {
    // Example: Setting the entire row or larger blocks at once
    uint8_t fullRow[32]; // Adjust the size based on how much you can write at once
    memset(fullRow, 0xff, sizeof(fullRow));

    for (uint8_t y = 0; y < 32; y++) {
        setGDRAMAddress(0, y); // Set the starting address only once per row
        for (uint8_t x = 0; x < 16; x += 1) {
            sendData(0xff);
            sendData(0xff);
        }
    }
}
void restartPixelRows(uint8_t startY, uint8_t endY) {
    
    for (uint8_t y = startY; y < endY; y++) {
        setGDRAMAddress(0, startY); // Set the starting address only once per row
        for (uint8_t x = 0; x < 16; x += 1) {
            sendData(0xff);
            sendData(0xff);
        }
    }
}

void turnOffAllPixels() {
    // Example: Setting the entire row or larger blocks at once
    uint8_t emptyRow[32]; // Adjust the size based on how much you can write at once
    memset(emptyRow, 0, sizeof(emptyRow));

    for (uint8_t y = 0; y < 64; y++) {
        setGDRAMAddress(0, y); // Set the starting address only once per row
        for (uint8_t x = 0; x < 16; x += sizeof(emptyRow) / 2) {
            for (uint8_t i = 0; i < sizeof(emptyRow); i += 2) {
                sendData(emptyRow[i]);
                sendData(emptyRow[i + 1]);
            }
        }
    }
}

void setWord(uint8_t x, uint8_t y, uint8_t byte1, uint8_t byte2) {
    // Validity checks
    if (x > 111 || y > 63) {
        return;
    }

    uint8_t horizontalAddress = x / 16;
    uint8_t startPixel = x % 16;
    uint8_t endPixel = startPixel + 15;

    uint8_t overlapping = 0;
    uint8_t overlap = 0;

    // Calculate vertical address
    if (y >= 32) {
        y -= 32; // Reset y to the range 0-31
        horizontalAddress += 8; // Adjust to the second half of the screen
    }
    if (startPixel > 8) {
        overlap = 8 - (startPixel - 8);
        startPixel = 8 - (16 - startPixel);
        overlapping = 1;
    } else {
        overlap = 8 - startPixel;
    }

    uint8_t firstByteMask = 0;
    uint8_t secondByteMask = 0;

    char debugStr[300];
    //sprintf(debugStr, "x: %u, y: %u, horizontalAddress: %u, startPixel: %u, endPixel: %u\r\n", x, y, horizontalAddress, startPixel, endPixel);
    //UART_1_PutString(debugStr);

    //sprintf(debugStr, "Initial byte1: %02X, byte2: %02X\r\n", byte1, byte2);
    //UART_1_PutString(debugStr);

    if (startPixel == 0) {
        setGDRAMAddress(horizontalAddress, y);
        sendData(byte2);
        sendData(byte1);

        //sprintf(debugStr, "Sending byte2: %02X, byte1: %02X\r\n", byte2, byte1);
        //UART_1_PutString(debugStr);
    } else {
        //sprintf(debugStr, "Overlapping: %d, StartPixel: %u, Overlap: %u\r\n", overlapping, startPixel, overlap);
        //UART_1_PutString(debugStr);

        if (overlapping == 0) {
            firstByteMask = byte1 << startPixel;
            
            
            secondByteMask = (byte1 >> overlap) | (byte2 << startPixel);
            

            //sprintf(debugStr, "Step 1 - Non-overlapping: firstByteMask = %02X (byte1 << startPixel), secondByteMask = %02X ((byte1 >> overlap) | (byte2 << startPixel))\r\n", firstByteMask, secondByteMask);
            //UART_1_PutString(debugStr);
        } else {
            firstByteMask = 0x00; // nothing on the first 8 bits
            secondByteMask = byte1 << startPixel;

            //sprintf(debugStr, "Step 1 - Overlapping: firstByteMask = %02X, secondByteMask = %02X (byte1 << startPixel)\r\n", firstByteMask, secondByteMask);
            //UART_1_PutString(debugStr);
        }

        setGDRAMAddress(horizontalAddress, y);
        sendData(secondByteMask);
        sendData(firstByteMask);
        
        

        //sprintf(debugStr, "First segment: firstByteMask = %02X, secondByteMask = %02X\r\n", firstByteMask, secondByteMask);
        //UART_1_PutString(debugStr);

        //sprintf(debugStr, "Sending firstByteMask: %02X, secondByteMask: %02X\r\n", firstByteMask, secondByteMask);
        //UART_1_PutString(debugStr);

        // For the next 16-pixel segment (if needed)
        if (endPixel > 15) {
            //sprintf(debugStr, "Processing next 16-pixel segment\r\n");
            //UART_1_PutString(debugStr);

            if (overlapping == 0) {
                firstByteMask = byte2 >> overlap;
                secondByteMask = 0x00;

                //sprintf(debugStr, "Step 2 - Non-overlapping: firstByteMask = %02X (byte2 >> overlap), secondByteMask = %02X\r\n", firstByteMask, secondByteMask);
                //UART_1_PutString(debugStr);
            } else {
                firstByteMask = (byte1 >> overlap) | (byte2 << startPixel);
                secondByteMask = byte2 >> overlap;

                //sprintf(debugStr, "Step 2 - Overlapping: firstByteMask = %02X ((byte1 >> overlap) | (byte2 << startPixel)), secondByteMask = %02X (byte2 >> overlap)\r\n", firstByteMask, secondByteMask);
                //UART_1_PutString(debugStr);
            }

            setGDRAMAddress(horizontalAddress + 1, y);
            sendData(secondByteMask);
            sendData(firstByteMask);
            
            

            //sprintf(debugStr, "Second segment: firstByteMask = %02X, secondByteMask = %02X\r\n", firstByteMask, secondByteMask);
            //UART_1_PutString(debugStr);

            //sprintf(debugStr, "Sending firstByteMask: %02X, secondByteMask: %02X\r\n", firstByteMask, secondByteMask);
            //UART_1_PutString(debugStr);
        }
    }
}

void setPixel(uint8_t x, uint8_t y) {
    // Validity checks
    if (x > 127 || y > 63) {
        return; // invalid pixel position
    }

    // Calculate the horizontal address and the byte to modify
    uint8_t horizontalAddress = (x / 16)-1;    // There are 16 horizontal addresses (0 to 15)
    uint8_t byteToModify = (x % 16) < 8 ? 1 : 2;   // 1 = first byte, 2 = second byte

    uint8_t pixelPosition = x % 8;      // Position within the byte (0 to 7)
    uint8_t mask = 1 << pixelPosition;  // Mask for the pixel

    // Calculate vertical address 
    if (y >= 32) {
        y -= 32;                       // Reset y to the range 0-31
        horizontalAddress += 8;        // Adjust to the second half of the screen
    }

    setGDRAMAddress(horizontalAddress, y);

    if (byteToModify == 1) {
        // If we are modifying the first byte, read its current value
        uint8_t currentData1 = readData(0); // no skip dummy
        uint8_t currentData2 = readData(1); // skip dummy
        sendData(currentData1 | mask);  // Modify the bit and send the data back
        sendData(currentData2);         // Send the second byte unmodified
    } else {
        // If we are modifying the second byte, read its current value
        uint8_t currentData1 = readData(0); // no skip dummy
        uint8_t currentData2 = readData(1); // skip dummy
        sendData(currentData1);         // Send the first byte unmodified
        sendData(currentData2 | mask);  // Modify the bit and send the data back
    }
}

#include <stdint.h>

void convertBlockColumnToRowMajor(const uint8_t* src, uint8_t* dest, int srcHeight, int srcWidth) {
    int numRows = srcHeight / 8;  // Number of 8-pixel rows (bytes per column)
    int numBlocks = srcWidth / 8; // Number of 8-column blocks

    // Process each block of 8x8
    for (int block = 0; block < numBlocks; block++) {
        for (int row = 0; row < 8; row++) {
            uint8_t newRow = 0;
            for (int col = 0; col < 8; col++) {
                int srcIndex = block * numRows + col;
                if (src[srcIndex] & (1 << row)) {
                    newRow |= (1 << col);
                }
            }
            dest[block * 8 + row] = newRow;
        }
    }
}



void displayImage(const uint8_t* data, uint8_t startX, uint8_t startY) {
    for (int i = 0; i < 16; ++i) {
        // Get the bytes for the current row
        uint8_t byte1 = data[i * 2];
        uint8_t byte2 = data[i * 2 + 1];

        // Set the word for the entire row
        setWord(startX, startY + i, byte1, byte2);
    }
}

void displayImage32(const uint8_t* data, uint8_t startX, uint8_t startY) {
    for (int i = 0; i < 32; ++i) { // Assuming 32 rows.
        // For each row, we have 4 bytes representing 32 bits.
        // Split this into two calls to setWord, each handling 16 bits.

        // Index calculation needs to account for 4 bytes per row now.
        int index = i * 4; // 4 bytes per row

        // First 16 bits of the current row
        uint8_t byte1 = data[index];
        uint8_t byte2 = data[index + 1];
        // Call setWord with the first 16 bits
        

        // Next 16 bits of the current row
        uint8_t byte3 = data[index + 2];
        uint8_t byte4 = data[index + 3];
        // Call setWord with the next 16 bits, incrementing startX to move to the right
        setWord(startX, startY + i, byte4, byte3);
        setWord(startX + 16, startY + i, byte2, byte1);
    }
}

void displayImage64(const uint8_t* data, uint8_t startX, uint8_t startY) {
    for (int i = 0; i < 48; ++i) { // Corrected assumption to 48 rows if your image is 48x48
        // Index calculation assumes 6 bytes per row now.
        int index = i * 6; // 6 bytes per row

        // Process each row in three calls to setWord, each handling 16 bits (2 bytes).
        uint8_t byte1 = data[index];
        uint8_t byte2 = data[index + 1];
        uint8_t byte3 = data[index + 2];
        uint8_t byte4 = data[index + 3];
        uint8_t byte5 = data[index + 4];
        uint8_t byte6 = data[index + 5];

        char debugStr[200];
        //sprintf(debugStr, "Row %d: byte1 = %02X, byte2 = %02X, byte3 = %02X, byte4 = %02X, byte5 = %02X, byte6 = %02X\r\n", i, byte1, byte2, byte3, byte4, byte5, byte6);
        //UART_1_PutString(debugStr);

        // Call setWord with the first, second, and third 16-bit chunks
        setWord(startX, startY + i, byte6, byte5);
        setWord(startX + 16, startY + i, byte4, byte3);
        setWord(startX + 32, startY + i, byte2, byte1);
    }
}


void displayAnimation(const uint8_t frames[][288], uint8_t startX, uint8_t startY, int startFrame, int endFrame) {
    for (int frame = startFrame; frame < endFrame; ++frame) {
        // Each frame is intro[frame], which automatically points to the start of each 288-byte frame
        displayImage64(frames[frame], startX, startY);
    }
}

void displayLine(uint8_t startY) {
    for (int x = 0; x<112; x+=16) {
        setWord(x,startY,0xff,0xff);}
};