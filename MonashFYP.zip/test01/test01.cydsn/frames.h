/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#include <stdio.h>
#include <stdint.h>

const uint8_t intro[29][288];
const uint8_t gear[29][288];
const uint8_t speed[29][32];
const uint8_t speed_2[29][128];
const uint8_t error[29][288];