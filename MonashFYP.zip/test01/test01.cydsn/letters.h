/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#ifndef LETTERS_H
#define LETTERS_H

#include <stdint.h>

const uint8_t charA[8];
const uint8_t charB[8];
const uint8_t charC[8];
const uint8_t charD[8];
const uint8_t charE[8];
const uint8_t charF[8];
const uint8_t charG[8];
const uint8_t charH[8];
const uint8_t charI[8];
const uint8_t charJ[8];
const uint8_t charK[8];
const uint8_t charL[8];
const uint8_t charM[8];
const uint8_t charN[8];
const uint8_t charO[8];
const uint8_t charP[8];
const uint8_t charQ[8];
const uint8_t charR[8];
const uint8_t charS[8];
const uint8_t charT[8];
const uint8_t charU[8];
const uint8_t charV[8];
const uint8_t charW[8];
const uint8_t charX[8];
const uint8_t charY[8];
const uint8_t charZ[8];




const uint8_t* getCharBitmap(char c);



#endif