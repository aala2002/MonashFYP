/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// menu.h
#ifndef MENU_H
#define MENU_H

#include <stdint.h> // For uint8_t

// Forward declaration
struct MenuPage;

// MenuItem structure
typedef struct MenuItem {
    const char* name;
    void (*action)(void);
    struct MenuPage* submenu;
} MenuItem;

// MenuPage structure
typedef struct MenuPage {
    char* title;
    MenuItem* items;
    int numberOfItems;
    int selectedItem;
    struct MenuPage* parentMenu; // Optional, for tracking parent menu
} MenuPage;

// Function prototypes
void initializeMainMenu(void);
void displayMenuWithHighlight(int highlightedItem);
void navigateUp(void);
void navigateDown(void);
void selectMenuItem(void);
void goBack(void);
void setParentMenu(MenuPage* parent);
void setCurrentMenu(MenuPage* menu);
void stopCurrentAction(void);


void displayTwoCharsDirectly(const uint8_t* bitmap1, const uint8_t* bitmap2, uint8_t startX, uint8_t startY);
void displayTwoCharsDirectlyInversed(const uint8_t* bitmap1, const uint8_t* bitmap2, uint8_t startX, uint8_t startY);
void displayText(const char* str, uint8_t startX, uint8_t startY);
void displayTextInversed(const char* str, uint8_t startX, uint8_t startY);
void displayMenuWithHighlight(int highlightedItem);                    //Function that should refresh everytime I am trying to switch (this is because untill now the best method I found was when I was switching menu I will need to refresh the whole display
    

#define MENU_ITEM_HEIGHT 10 // Assuming each menu item takes 8 rows


typedef enum {
    RAW_DATA,
    INTERPRETED_DATA
} DataType;

static DataType currentDataType = INTERPRETED_DATA;

#define MAX_DISPLAY_MESSAGES 3  // Maximum messages that can be shown at once, excluding the header

void displayCANMessages(char messages[][17], int numMessages);

void updateDisplayWithNewMessage(char newMessage[17]);

#endif // MENU_H


/* [] END OF FILE */
